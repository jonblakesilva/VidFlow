# VidFlow - 5 Minute Quick Start 🚀

Get VidFlow live in 5 minutes. Seriously.

---

## ⚡ Super Quick Deploy

### 1. Create GitHub Repo (1 minute)

```bash
# Run the setup script
./setup-github.sh

# Follow the on-screen instructions
# It will commit everything and show you what to do next
```

**Manual steps:**
1. Go to https://github.com/new
2. Repository name: `vidflow-widget-builder`
3. Public repository
4. Click "Create repository"
5. Copy the commands shown, paste in terminal

```bash
git remote add origin https://github.com/YOUR_USERNAME/vidflow-widget-builder.git
git branch -M main
git push -u origin main
```

### 2. Deploy to Vercel (2 minutes)

1. Go to https://vercel.com/new
2. Sign in with GitHub
3. Click "Import" next to your `vidflow-widget-builder` repo
4. Click "Deploy" (don't change any settings)
5. Wait 2-3 minutes ⏱️
6. Copy your URL: `https://vidflow-widget-builder-xyz.vercel.app`

### 3. Embed in GoHighLevel (2 minutes)

1. In GHL, go to Sites → Pages → Your Page
2. Add a **Custom HTML** element
3. Paste this code:

```html
<iframe 
  src="https://YOUR-VERCEL-URL.vercel.app" 
  width="100%" 
  height="100vh" 
  frameborder="0"
  allow="autoplay; fullscreen"
  style="border: none;"
></iframe>
```

4. Replace `YOUR-VERCEL-URL` with your actual Vercel URL
5. Save and publish

### 4. Test It! (30 seconds)

1. Visit your GHL page
2. See the VidFlow builder load
3. Play with the settings
4. Watch the Rick Roll demo 🎵

---

## ✅ Done!

You now have:
- ✅ A live video widget builder
- ✅ Embedded in GoHighLevel
- ✅ Ready for clients to use
- ✅ Professional and polished

---

## 🎯 What's Next?

### Immediate (Do This Now)
- Record a real 30-second video for your business
- Replace the Rick Roll with your video
- Show it to one client

### This Week
- Create 2-3 template widgets
- Add to your sales materials
- Set up tracking/analytics

### This Month
- White-label for clients
- Create video tutorials
- Build template library

---

## 🐛 Quick Troubleshooting

**Build fails?**
```bash
npm run build
# Look for errors, fix them, try again
```

**Can't push to GitHub?**
```bash
# Make sure you created the repo on GitHub first
# Check your GitHub username in the remote URL
git remote -v
```

**Vercel deploy fails?**
- Check Vercel deployment logs
- Make sure build succeeded locally
- Try deploying again (it works 99% of the time)

**iframe not showing?**
- Check the URL is correct
- Make sure iframe code is in Custom HTML
- Try opening Vercel URL directly first

---

## 💡 Pro Tips

1. **Custom Domain**: Add `builder.yourdomain.com` in Vercel settings
2. **Updates**: Just `git push` and Vercel redeploys automatically
3. **Multiple Versions**: Create branches for testing new features
4. **Analytics**: Add Google Analytics in `index.html`
5. **Backup**: GitHub is your backup. Everything is safe.

---

## 📞 Need Help?

**Check these first:**
- ✅ README.md - Full documentation
- ✅ DEPLOYMENT.md - Detailed deployment guide
- ✅ CHECKLIST.md - Verify everything is set up

**Still stuck?**
- Check Vercel logs (in Vercel dashboard)
- Review browser console (F12)
- Test locally first: `npm run dev`

---

## 🎉 Success!

If you can see the builder in your browser, you're done!

Now go create some amazing video widgets! 🎬

---

**Questions? Everything is documented. You got this! 💪**
