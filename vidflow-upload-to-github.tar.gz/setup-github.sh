#!/bin/bash

# VidFlow - GitHub Setup Script
# This script initializes git and sets up the repository

echo "🚀 Setting up VidFlow for GitHub..."
echo ""

# Initialize git if not already initialized
if [ ! -d ".git" ]; then
  echo "📦 Initializing Git repository..."
  git init
  echo "✅ Git initialized"
else
  echo "✅ Git already initialized"
fi

# Add all files
echo ""
echo "📝 Adding files to git..."
git add .

# Check if there are changes to commit
if git diff-index --quiet HEAD --; then
  echo "⚠️  No changes to commit"
else
  # Commit
  echo ""
  echo "💾 Committing changes..."
  git commit -m "Initial commit - VidFlow Widget Builder

  - Interactive video widget builder for GoHighLevel
  - YouTube and MP4 video support
  - Visual customization panel
  - GHL form integration
  - One-click embed code generation
  - Fully responsive and mobile-friendly
  - Production ready with Vercel deployment config"
  echo "✅ Changes committed"
fi

echo ""
echo "🎯 Next Steps:"
echo ""
echo "1. Create a new repository on GitHub:"
echo "   → Go to https://github.com/new"
echo "   → Name: vidflow-widget-builder"
echo "   → Description: Interactive video widget builder for GoHighLevel"
echo "   → Make it Public (recommended) or Private"
echo "   → DO NOT initialize with README (we have one)"
echo ""
echo "2. Add the remote and push:"
echo "   → git remote add origin https://github.com/YOUR_USERNAME/vidflow-widget-builder.git"
echo "   → git branch -M main"
echo "   → git push -u origin main"
echo ""
echo "3. Deploy to Vercel:"
echo "   → Visit https://vercel.com/new"
echo "   → Import your GitHub repository"
echo "   → Click Deploy (Vercel auto-detects settings)"
echo "   → Wait 2-3 minutes"
echo "   → Your app is live! 🎉"
echo ""
echo "4. Embed in GoHighLevel:"
echo "   → Copy your Vercel URL"
echo "   → Use the iframe code from DEPLOYMENT.md"
echo ""
echo "📚 Documentation:"
echo "   - README.md - Project overview"
echo "   - DEPLOYMENT.md - Detailed deployment guide"
echo "   - Check the /docs folder for more"
echo ""
echo "✨ All set! Ready to push to GitHub."
