
export type WidgetPosition = 'bottom-right' | 'bottom-left' | 'top-right' | 'top-left';
export type WidgetStyle = 'floating' | 'fixed';
export type GhlInputMethod = 'code' | 'id_url';
export type GhlDisplayMode = 'under-video' | 'slide-up' | 'replace-video';
export type GhlSuccessAction = 'message' | 'close' | 'redirect';

export interface OverlayButton {
  id: string;
  label: string;
  link: string;
  backgroundColor: string;
  textColor: string;
  openInNewTab: boolean;
}

export interface WidgetConfig {
  // Video & General
  videoUrl: string; // Added to make the widget functional
  videoWidth: number;
  themeColor: string;
  avatarUrl: string;
  showAvatarToggle: boolean;
  widgetStyle: WidgetStyle;
  position: WidgetPosition;
  
  // Overlay Buttons
  buttons: OverlayButton[];

  // GoHighLevel Settings
  ghlEnabled: boolean;
  ghlInputMethod: GhlInputMethod;
  ghlEmbedCode: string;
  ghlFormIdOrUrl: string;
  ghlDisplayMode: GhlDisplayMode;
  ghlSuccessAction: GhlSuccessAction;
  ghlRedirectUrl: string;
  ghlThankYouMessage: string;
}

export const INITIAL_CONFIG: WidgetConfig = {
  // Rick Roll demo video - Using embedded YouTube format
  videoUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ?autoplay=1&mute=1&loop=1&playlist=dQw4w9WgXcQ', 
  videoWidth: 360,
  themeColor: '#ff4444', // Rick Roll red theme
  avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-1.2.1&auto=format&fit=crop&w=200&q=80',
  showAvatarToggle: true,
  widgetStyle: 'floating',
  position: 'bottom-right',
  buttons: [
    {
      id: 'btn-1',
      label: '🎵 Never Gonna Give You Up',
      link: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
      backgroundColor: '#ff4444',
      textColor: '#ffffff',
      openInNewTab: true
    },
    {
      id: 'btn-2',
      label: 'Book a Consultation',
      link: '#',
      backgroundColor: '#6366f1',
      textColor: '#ffffff',
      openInNewTab: false
    }
  ],
  ghlEnabled: true,
  ghlInputMethod: 'id_url',
  ghlEmbedCode: '',
  ghlFormIdOrUrl: '',
  ghlDisplayMode: 'slide-up',
  ghlSuccessAction: 'message',
  ghlRedirectUrl: '',
  ghlThankYouMessage: 'Thanks! We will be in touch shortly.',
};
