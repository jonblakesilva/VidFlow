# VidFlow Deployment Guide

## 🚀 Deploy to Vercel (5 Minutes)

### Step 1: Push to GitHub

```bash
# Initialize git repository (if not already done)
git init

# Add all files
git add .

# Commit
git commit -m "Initial commit - VidFlow Widget Builder"

# Create repository on GitHub (visit https://github.com/new)
# Repository name: vidflow-widget-builder
# Then add remote and push:
git remote add origin https://github.com/YOUR_USERNAME/vidflow-widget-builder.git
git branch -M main
git push -u origin main
```

### Step 2: Deploy to Vercel

**Option A: Use the Vercel Dashboard**

1. Go to [vercel.com](https://vercel.com)
2. Sign in with GitHub
3. Click "Add New Project"
4. Import your `vidflow-widget-builder` repository
5. Vercel auto-detects settings (Vite framework)
6. Click "Deploy"
7. Wait 2-3 minutes
8. Your app is live! 🎉

**Option B: Use Vercel CLI**

```bash
# Install Vercel CLI
npm i -g vercel

# Login to Vercel
vercel login

# Deploy
vercel

# Deploy to production
vercel --prod
```

### Step 3: Get Your URL

After deployment, Vercel provides:
- **Preview URL**: `https://vidflow-widget-builder-abc123.vercel.app`
- **Production URL**: `https://your-domain.vercel.app`

You can also add a custom domain in Vercel settings.

---

## 🔗 Embed in GoHighLevel

### Method 1: Full Page iframe

1. In GHL, create a new **Custom HTML** section
2. Paste this code:

```html
<iframe 
  src="https://your-vercel-url.vercel.app" 
  width="100%" 
  height="100vh" 
  frameborder="0"
  allow="autoplay; fullscreen"
  style="border: none; min-height: 100vh;"
></iframe>
```

3. Adjust height as needed

### Method 2: Section iframe

```html
<div style="width: 100%; height: 800px; overflow: hidden;">
  <iframe 
    src="https://your-vercel-url.vercel.app" 
    width="100%" 
    height="100%" 
    frameborder="0"
    allow="autoplay; fullscreen"
    style="border: none;"
  ></iframe>
</div>
```

### Method 3: Popup iframe

```html
<button onclick="openBuilder()">Open Widget Builder</button>

<div id="builderModal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.8); z-index: 9999;">
  <div style="position: relative; width: 90%; height: 90%; margin: 5% auto; background: white; border-radius: 12px; overflow: hidden;">
    <button onclick="closeBuilder()" style="position: absolute; top: 10px; right: 10px; z-index: 10000; background: #000; color: white; border: none; padding: 10px 20px; border-radius: 6px; cursor: pointer;">Close</button>
    <iframe 
      src="https://your-vercel-url.vercel.app" 
      width="100%" 
      height="100%" 
      frameborder="0"
      allow="autoplay; fullscreen"
      style="border: none;"
    ></iframe>
  </div>
</div>

<script>
  function openBuilder() {
    document.getElementById('builderModal').style.display = 'block';
  }
  function closeBuilder() {
    document.getElementById('builderModal').style.display = 'none';
  }
</script>
```

---

## ⚙️ Vercel Configuration

The `vercel.json` file includes:

- **Build Command**: `npm run build`
- **Output Directory**: `dist`
- **Framework**: Vite (auto-detected)
- **Headers**: Configured for iframe embedding

### Important Headers

```json
{
  "X-Frame-Options": "ALLOWALL",
  "Content-Security-Policy": "frame-ancestors *",
  "Access-Control-Allow-Origin": "*"
}
```

These allow the app to be embedded in iframes from any domain (required for GHL).

---

## 🔧 Custom Domain Setup

### Add Custom Domain in Vercel

1. Go to your project in Vercel
2. Click "Settings" → "Domains"
3. Add your domain (e.g., `builder.arboradvantage.com`)
4. Follow DNS configuration instructions
5. Wait for SSL certificate (automatic)

### DNS Configuration Example

**For Subdomain** (builder.yourdomain.com):
- Type: `CNAME`
- Name: `builder`
- Value: `cname.vercel-dns.com`

**For Root Domain** (yourdomain.com):
- Type: `A`
- Name: `@`
- Value: `76.76.21.21`

---

## 🧪 Testing

### Before Deployment

```bash
# Run local build
npm run build

# Preview production build
npm run preview

# Visit http://localhost:4173
```

### After Deployment

1. **Test Direct Access**: Visit your Vercel URL
2. **Test iframe Embed**: Embed in a test HTML page
3. **Test in GHL**: Create test page with iframe
4. **Test Video Playback**: Ensure YouTube/MP4 works
5. **Test Form Generation**: Download .js file
6. **Test Mobile**: Check responsiveness

---

## 🔄 Updates & Redeployment

### Automatic Deployments

Vercel automatically deploys when you push to GitHub:

```bash
# Make changes
git add .
git commit -m "Update: Added new feature"
git push

# Vercel deploys automatically
# Check deployment status in Vercel dashboard
```

### Manual Deployments

```bash
# Deploy from CLI
vercel --prod

# Or use Vercel dashboard "Redeploy" button
```

---

## 📊 Environment Variables

If you need environment variables:

### In Vercel Dashboard

1. Go to Project → Settings → Environment Variables
2. Add key-value pairs
3. Redeploy

### Example `.env` file (for local development)

```bash
VITE_API_URL=https://api.example.com
VITE_GA_ID=UA-XXXXXXXXX-X
```

Access in code:
```typescript
const apiUrl = import.meta.env.VITE_API_URL;
```

---

## 🐛 Troubleshooting

### Build Fails on Vercel

**Check:**
- Node version (use 18.x or 20.x)
- Package.json scripts
- TypeScript errors

**Fix:**
```bash
# Test build locally first
npm run build

# Check for errors
npm run build 2>&1 | grep -i error
```

### iframe Not Loading

**Check:**
1. Vercel headers in `vercel.json`
2. Browser console for CSP errors
3. Mixed content (HTTP vs HTTPS)

**Fix:**
- Ensure all URLs use HTTPS
- Check `vercel.json` headers
- Test in different browser

### Video Not Playing

**Check:**
1. Video URL is accessible
2. YouTube embed format is correct
3. Browser autoplay policy

**Fix:**
- Use YouTube embed URL: `/embed/VIDEO_ID`
- Videos start muted for autoplay
- Test with different video source

---

## 📈 Performance Optimization

### Already Optimized

- ✅ Vite build optimization
- ✅ Code splitting
- ✅ Tree shaking
- ✅ Minification
- ✅ Gzip compression

### Optional Enhancements

1. **Add Analytics**
```html
<!-- In index.html -->
<script async src="https://www.googletagmanager.com/gtag/js?id=GA_ID"></script>
```

2. **Add Sentry Error Tracking**
```bash
npm install @sentry/react
```

3. **Optimize Images**
- Use WebP format
- Compress images
- Lazy load images

---

## 🔐 Security

### Current Security Measures

- HTTPS only (Vercel automatic)
- CORS headers configured
- No sensitive data stored
- XSS protection via React
- CSP headers configured

### Additional Security (Optional)

1. **Rate Limiting**: Add Vercel rate limiting
2. **API Keys**: Use environment variables
3. **User Auth**: Add authentication if needed

---

## 💰 Pricing

### Vercel Free Tier

- ✅ Unlimited deployments
- ✅ Automatic HTTPS
- ✅ 100GB bandwidth/month
- ✅ Perfect for this project

### If You Need More

**Pro Plan** ($20/month):
- 1TB bandwidth
- Advanced analytics
- Team collaboration

---

## 📞 Support

### Vercel Issues
- [Vercel Documentation](https://vercel.com/docs)
- [Vercel Support](https://vercel.com/support)

### VidFlow Issues
- Check GitHub Issues
- Review error logs in Vercel dashboard
- Test locally first

---

## ✅ Deployment Checklist

Before going live:

- [ ] Test build locally (`npm run build`)
- [ ] Push to GitHub
- [ ] Deploy to Vercel
- [ ] Test deployed URL
- [ ] Test iframe embed
- [ ] Test in GHL
- [ ] Verify all videos play
- [ ] Test on mobile
- [ ] Check console for errors
- [ ] Update README with live URL
- [ ] Add custom domain (optional)
- [ ] Set up analytics (optional)

---

## 🎯 Next Steps After Deployment

1. **Share with clients**: Send them your Vercel URL
2. **Create documentation**: Add to your knowledge base
3. **Monitor usage**: Check Vercel analytics
4. **Gather feedback**: Improve based on user input
5. **Create templates**: Build pre-configured widgets

---

**Your VidFlow builder will be live in under 5 minutes!** 🚀
