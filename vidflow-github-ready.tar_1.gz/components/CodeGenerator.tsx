
import React, { useState } from 'react';
import { WidgetConfig } from '../types';
import { Copy, Check, AlertTriangle, Download, FileJson, FileCode } from 'lucide-react';

interface CodeGeneratorProps {
  config: WidgetConfig;
}

const CodeGenerator: React.FC<CodeGeneratorProps> = ({ config }) => {
  const [copied, setCopied] = useState(false);
  const [activeTab, setActiveTab] = useState<'inline' | 'file'>('file');

  // Validation
  const isGhlInvalid = config.ghlEnabled && (
      (config.ghlInputMethod === 'code' && !config.ghlEmbedCode.trim()) ||
      (config.ghlInputMethod === 'id_url' && !config.ghlFormIdOrUrl.trim())
  );

  // This is the vanilla JS runtime that will be inside the downloaded file
  const getRuntimeScript = (configJson: string) => `
(function() {
  var config = ${configJson};
  if (!config.videoUrl) return;

  function createEl(tag, cls, content) {
    var el = document.createElement(tag);
    if (cls) el.className = cls;
    if (content) el.innerHTML = content;
    return el;
  }

  // --- Styles ---
  if (!document.getElementById('vidflow-style')) {
    var style = document.createElement('style');
    style.id = 'vidflow-style';
    style.innerHTML = \`
      .vv-widget-container {
        position: fixed; z-index: 10000; bottom: 20px; right: 20px;
        display: flex; flex-direction: column; align-items: flex-end;
        font-family: 'Inter', system-ui, -apple-system, sans-serif;
      }
      .vv-widget-container.bottom-left { right: auto; left: 20px; align-items: flex-start; }
      .vv-widget-container.top-right { bottom: auto; top: 20px; }
      .vv-widget-container.top-left { bottom: auto; right: auto; top: 20px; left: 20px; align-items: flex-start; }
      
      .vv-avatar {
        width: 60px; height: 60px; border-radius: 50%; 
        border: 3px solid \${config.themeColor}; 
        background: #fff; cursor: pointer; overflow: hidden;
        box-shadow: 0 4px 15px rgba(0,0,0,0.2);
        transition: transform 0.3s ease;
        position: relative; z-index: 2; margin-top: 10px;
      }
      .vv-avatar:hover { transform: scale(1.05); }
      .vv-avatar img { width: 100%; height: 100%; object-fit: cover; }
      .vv-avatar-badge {
         position: absolute; top: 0; right: 0; width: 14px; height: 14px; background: #ef4444; border-radius: 50%; border: 2px solid white;
      }
      
      .vv-window {
        width: \${config.videoWidth}px;
        max-width: 90vw;
        background: #000; border-radius: 16px; overflow: hidden;
        box-shadow: 0 20px 50px rgba(0,0,0,0.3);
        opacity: 0; transform: translateY(20px) scale(0.95);
        transform-origin: bottom right;
        transition: all 0.3s cubic-bezier(0.16, 1, 0.3, 1);
        pointer-events: none; position: absolute; bottom: 80px; right: 0;
        display: flex; flex-direction: column;
      }
      .vv-widget-container.bottom-left .vv-window { right: auto; left: 0; transform-origin: bottom left; }
      .vv-widget-container.top-right .vv-window { bottom: auto; top: 80px; transform-origin: top right; }
      .vv-widget-container.top-left .vv-window { bottom: auto; right: auto; top: 80px; left: 0; transform-origin: top left; }
      
      .vv-window.open { opacity: 1; transform: translateY(0) scale(1); pointer-events: all; position: relative; bottom: auto; right: auto; margin-bottom: 0; }
      
      .vv-video-wrap { position: relative; width: 100%; aspect-ratio: 9/16; cursor: pointer; background: #000; flex-shrink: 0; }
      .vv-video-wrap video { width: 100%; height: 100%; object-fit: cover; display: block; }
      .vv-play-overlay { position: absolute; inset: 0; display: flex; align-items: center; justify-content: center; background: rgba(0,0,0,0.2); transition: opacity 0.3s; }
      .vv-play-overlay.hidden { opacity: 0; pointer-events: none; }
      .vv-play-icon { width: 60px; height: 60px; background: rgba(255,255,255,0.2); backdrop-filter: blur(4px); border-radius: 50%; display: flex; align-items: center; justify-content: center; transition: transform 0.2s; }
      .vv-video-wrap:hover .vv-play-icon { transform: scale(1.1); background: rgba(255,255,255,0.3); }
      .vv-play-icon::after { content: ''; display: block; width: 0; height: 0; border-style: solid; border-width: 10px 0 10px 18px; border-color: transparent transparent transparent white; margin-left: 6px; }
      
      .vv-close-btn { position: absolute; top: 12px; right: 12px; width: 32px; height: 32px; background: rgba(0,0,0,0.3); border-radius: 50%; color: white; border: none; font-size: 20px; display: flex; align-items: center; justify-content: center; cursor: pointer; z-index: 10; backdrop-filter: blur(4px); transition: background 0.2s; }
      .vv-close-btn:hover { background: rgba(0,0,0,0.6); }
      
      .vv-content { background: #fff; padding: 16px; position: relative; border-top: 1px solid rgba(0,0,0,0.05); }
      .vv-button { display: block; text-align: center; padding: 12px; border-radius: 8px; margin-bottom: 8px; text-decoration: none; font-weight: 600; font-size: 14px; transition: transform 0.1s, opacity 0.2s; box-shadow: 0 2px 5px rgba(0,0,0,0.05); }
      .vv-button:hover { opacity: 0.95; }
      .vv-button:active { transform: scale(0.98); }
      
      .vv-ghl-container { margin-top: 10px; border-top: 1px dashed #e5e7eb; padding-top: 10px; }
      .vv-ghl-frame { width: 100%; border: none; min-height: 400px; background: #fff; }
    \`;
    document.head.appendChild(style);
  }

  // --- DOM Structure ---
  var container = createEl('div', 'vv-widget-container ' + config.position);
  if (config.widgetStyle === 'fixed') {
    container.style.position = 'relative';
    container.style.bottom = 'auto';
    container.style.right = 'auto';
    container.style.left = 'auto';
    container.style.alignItems = 'center';
  }
  document.body.appendChild(container);

  var windowEl = createEl('div', 'vv-window');
  container.appendChild(windowEl);

  // Video
  var videoWrap = createEl('div', 'vv-video-wrap');
  var video = document.createElement('video');
  video.src = config.videoUrl;
  video.loop = true;
  video.muted = false; 
  video.playsInline = true;
  video.setAttribute('webkit-playsinline', 'true');
  
  var playOverlay = createEl('div', 'vv-play-overlay');
  playOverlay.innerHTML = '<div class="vv-play-icon"></div>';
  
  videoWrap.appendChild(video);
  videoWrap.appendChild(playOverlay);
  
  // Close Button
  if (config.widgetStyle === 'floating') {
    var closeBtn = createEl('button', 'vv-close-btn', '&times;');
    closeBtn.onclick = function(e) {
      e.stopPropagation();
      toggleWidget(false);
    };
    windowEl.appendChild(closeBtn);
  }
  
  windowEl.appendChild(videoWrap);

  // Content Area
  var contentEl = createEl('div', 'vv-content');
  windowEl.appendChild(contentEl);

  // Buttons
  if (config.buttons && config.buttons.length > 0) {
    config.buttons.forEach(function(btn) {
      var a = createEl('a', 'vv-button', btn.label);
      a.href = btn.link;
      a.style.backgroundColor = btn.backgroundColor;
      a.style.color = btn.textColor;
      if (btn.openInNewTab) a.target = '_blank';
      contentEl.appendChild(a);
    });
  }
  
  // GHL Integration
  if (config.ghlEnabled && config.ghlInputMethod === 'id_url' && config.ghlFormIdOrUrl) {
    var ghlContainer = createEl('div', 'vv-ghl-container');
    var iframe = createEl('iframe', 'vv-ghl-frame');
    iframe.src = config.ghlFormIdOrUrl;
    ghlContainer.appendChild(iframe);
    contentEl.appendChild(ghlContainer);
  } else if (config.ghlEnabled && config.ghlInputMethod === 'code' && config.ghlEmbedCode) {
    // Basic support for embed code - risky if script, better if iframe
    var ghlContainer = createEl('div', 'vv-ghl-container');
    ghlContainer.innerHTML = config.ghlEmbedCode;
    contentEl.appendChild(ghlContainer);
    
    // Execute scripts if any in embed code (simplified)
    var scripts = ghlContainer.getElementsByTagName('script');
    for (var i = 0; i < scripts.length; i++) {
        var s = document.createElement('script');
        if (scripts[i].src) s.src = scripts[i].src;
        else s.innerHTML = scripts[i].innerHTML;
        document.body.appendChild(s);
    }
  }

  // Avatar Bubble
  if (config.showAvatarToggle && config.widgetStyle === 'floating') {
    var avatar = createEl('div', 'vv-avatar');
    if (config.avatarUrl) {
      avatar.innerHTML = '<img src="' + config.avatarUrl + '"><div class="vv-avatar-badge"></div>';
    }
    avatar.onclick = function() { toggleWidget(true); };
    container.appendChild(avatar);
  }

  // State Logic
  var isOpen = false;
  
  if (config.widgetStyle === 'fixed') {
      toggleWidget(true);
  }

  function toggleWidget(open) {
    isOpen = open;
    if (isOpen) {
      windowEl.classList.add('open');
      video.muted = false;
      var playPromise = video.play();
      if (playPromise !== undefined) {
        playPromise.catch(function(error) {
           console.log("Autoplay prevented, muting");
           video.muted = true;
           video.play();
        });
      }
      playOverlay.classList.add('hidden');
      if (avatar) avatar.style.display = 'none';
    } else {
      windowEl.classList.remove('open');
      video.pause();
      playOverlay.classList.remove('hidden');
      if (avatar) avatar.style.display = 'block';
    }
  }
  
  videoWrap.onclick = function() {
    if (video.paused) {
        video.play();
        playOverlay.classList.add('hidden');
    } else {
        video.pause();
        playOverlay.classList.remove('hidden');
    }
  };

})();
`;

  const getCleanConfig = () => {
    return {
        videoUrl: config.videoUrl,
        videoWidth: config.videoWidth,
        themeColor: config.themeColor,
        avatarUrl: config.avatarUrl,
        showAvatarToggle: config.showAvatarToggle,
        widgetStyle: config.widgetStyle,
        position: config.position,
        buttons: config.buttons.map(b => ({
            label: b.label,
            link: b.link,
            backgroundColor: b.backgroundColor,
            textColor: b.textColor,
            openInNewTab: b.openInNewTab
        })),
        ghlEnabled: config.ghlEnabled,
        ghlInputMethod: config.ghlInputMethod,
        ghlEmbedCode: config.ghlEmbedCode,
        ghlFormIdOrUrl: config.ghlFormIdOrUrl,
        ghlDisplayMode: config.ghlDisplayMode,
    };
  };

  const generateFileCode = () => {
      // Logic for users who download the JS file
      return `<!-- VidFlow Widget (Self-Hosted) -->
<script src="YOUR_UPLOADED_SCRIPT_URL_HERE"></script>`;
  };

  const generateInlineCode = () => {
     // Fully self-contained code
     const configJson = JSON.stringify(getCleanConfig());
     const runtime = getRuntimeScript(configJson);
     return `<!-- VidFlow Widget (Inline) -->
<script>
${runtime}
</script>`;
  };

  const handleDownload = () => {
    const configJson = JSON.stringify(getCleanConfig(), null, 2);
    // We wrap the config inside the runtime logic so the file is standalone
    const fileContent = getRuntimeScript(configJson);
    
    const blob = new Blob([fileContent], { type: 'text/javascript' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'vidflow.js';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleCopy = () => {
    if (isGhlInvalid) return;
    const code = activeTab === 'file' ? generateFileCode() : generateInlineCode();
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="bg-gray-900 text-gray-300 rounded-lg shadow-lg mt-8 border border-gray-700 overflow-hidden flex flex-col w-full">
      {/* Header Tabs */}
      <div className="flex border-b border-gray-700 bg-gray-950">
          <button 
            onClick={() => setActiveTab('file')}
            className={`flex-1 py-4 px-6 text-sm font-medium flex items-center justify-center gap-2 transition-colors ${activeTab === 'file' ? 'text-white border-b-2 border-indigo-500 bg-gray-900' : 'text-gray-500 hover:text-gray-300'}`}
          >
              <FileJson size={16} />
              Script File (Recommended)
          </button>
          <button 
            onClick={() => setActiveTab('inline')}
            className={`flex-1 py-4 px-6 text-sm font-medium flex items-center justify-center gap-2 transition-colors ${activeTab === 'inline' ? 'text-white border-b-2 border-indigo-500 bg-gray-900' : 'text-gray-500 hover:text-gray-300'}`}
          >
              <FileCode size={16} />
              Inline Code
          </button>
      </div>

      <div className="p-6">
        <div className="flex justify-between items-start mb-4">
            <div>
                <h3 className="text-white font-semibold">
                    {activeTab === 'file' ? 'Download & Host' : 'Copy & Paste'}
                </h3>
                <p className="text-xs text-gray-400 mt-1 max-w-md">
                    {activeTab === 'file' 
                        ? 'Download the .js file, upload it to your GoHighLevel Media Library, and paste the link below.' 
                        : 'Copy this entire block and paste it into the "Body Tracking Code" area of your funnel.'}
                </p>
            </div>
            
            {activeTab === 'file' && (
                <button
                    onClick={handleDownload}
                    disabled={isGhlInvalid}
                    className="flex items-center space-x-2 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded text-sm font-medium transition-all shadow-lg shadow-indigo-900/20"
                >
                    <Download size={16} />
                    <span>Download .js File</span>
                </button>
            )}
        </div>

        {isGhlInvalid && (
             <div className="mb-4 bg-red-900/20 border border-red-500/30 rounded p-3 flex items-start text-red-300 text-xs">
                 <AlertTriangle size={14} className="mr-2 mt-0.5 shrink-0" />
                 <span>Please fix GoHighLevel validation errors in the settings panel before generating code.</span>
             </div>
        )}

        <div className="relative group">
            <div className="absolute top-2 right-2">
                <button
                    onClick={handleCopy}
                    disabled={isGhlInvalid}
                    className={`flex items-center space-x-2 px-3 py-1.5 rounded text-xs font-medium transition-all border ${
                        isGhlInvalid 
                        ? 'bg-gray-800 border-gray-700 text-gray-500 cursor-not-allowed' 
                        : copied 
                            ? 'bg-green-900/30 border-green-800 text-green-400' 
                            : 'bg-gray-800 border-gray-600 text-gray-300 hover:bg-gray-700'
                    }`}
                >
                    {copied ? <Check size={14} /> : <Copy size={14} />}
                    <span>{copied ? 'Copied!' : 'Copy Code'}</span>
                </button>
            </div>
            <pre className="bg-gray-950 p-4 rounded-md overflow-x-auto text-xs font-mono border border-gray-800 h-48 scrollbar-thin scrollbar-thumb-gray-700 scrollbar-track-transparent">
                <code>{activeTab === 'file' ? generateFileCode() : generateInlineCode()}</code>
            </pre>
        </div>
        
        {activeTab === 'file' && (
            <div className="mt-4 p-3 bg-blue-900/20 border border-blue-800/30 rounded text-xs text-blue-200">
                <strong>Instruction:</strong> Replace <span className="font-mono bg-blue-900/50 px-1 rounded">YOUR_UPLOADED_SCRIPT_URL_HERE</span> in the code above with the link from your Media Library.
            </div>
        )}
      </div>
    </div>
  );
};

export default CodeGenerator;
