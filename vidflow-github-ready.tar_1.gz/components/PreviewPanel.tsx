
import React, { useState, useEffect } from 'react';
import { WidgetConfig } from '../types';
import { X, Play, MessageSquare, ChevronDown, AlertCircle } from 'lucide-react';

interface PreviewPanelProps {
  config: WidgetConfig;
}

const PreviewPanel: React.FC<PreviewPanelProps> = ({ config }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [showForm, setShowForm] = useState(false);
  const [videoError, setVideoError] = useState(false);
  const videoRef = React.useRef<HTMLVideoElement>(null);
  
  // Check if URL is YouTube
  const isYouTubeUrl = (url: string) => {
    return url.includes('youtube.com') || url.includes('youtu.be');
  };

  // Reset video error when URL changes
  useEffect(() => {
    setVideoError(false);
    setIsPlaying(false);
    if (videoRef.current) {
        videoRef.current.load();
    }
  }, [config.videoUrl]);

  // Auto-open logic for preview purposes when config changes significantly or initially
  useEffect(() => {
    // If fixed, it's always "open" in a way
    if (config.widgetStyle === 'fixed') {
        setIsOpen(true);
    }
  }, [config.widgetStyle]);

  // Handle Play/Pause
  const togglePlay = () => {
    if (videoError) return;
    if (videoRef.current) {
        if (isPlaying) {
            videoRef.current.pause();
        } else {
            // Attempt to play unmuted first (requires interaction usually)
            videoRef.current.muted = false;
            const playPromise = videoRef.current.play();
            if (playPromise !== undefined) {
                playPromise.catch(error => {
                    console.log("Auto-play prevented, falling back to muted", error);
                    if(videoRef.current) {
                        videoRef.current.muted = true;
                        videoRef.current.play();
                    }
                });
            }
        }
        setIsPlaying(!isPlaying);
    }
  };

  // Reset form view when closing
  useEffect(() => {
      if (!isOpen) {
          setShowForm(false);
          setIsPlaying(false);
          if (videoRef.current) {
              videoRef.current.pause();
              videoRef.current.currentTime = 0;
          }
      }
  }, [isOpen]);

  // Determine Position Classes
  const getPositionClasses = () => {
    if (config.widgetStyle === 'fixed') return 'relative mx-auto mt-10';
    
    switch (config.position) {
        case 'bottom-right': return 'absolute bottom-6 right-6';
        case 'bottom-left': return 'absolute bottom-6 left-6';
        case 'top-right': return 'absolute top-6 right-6';
        case 'top-left': return 'absolute top-6 left-6';
        default: return 'absolute bottom-6 right-6';
    }
  };

  // Avatar Component
  const AvatarBubble = () => (
      <div 
        onClick={() => setIsOpen(true)}
        className={`group cursor-pointer relative transition-transform hover:scale-105 active:scale-95 ${config.widgetStyle === 'fixed' ? 'hidden' : 'block'}`}
      >
          {/* Unread Badge */}
          <span className="absolute -top-1 -right-1 flex h-4 w-4">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-4 w-4 bg-red-500 text-[10px] text-white font-bold items-center justify-center">1</span>
          </span>

          <div 
            className="w-16 h-16 rounded-full overflow-hidden border-4 shadow-lg flex items-center justify-center bg-gray-200"
            style={{ borderColor: config.themeColor }}
          >
              {config.avatarUrl ? (
                  <img src={config.avatarUrl} alt="Avatar" className="w-full h-full object-cover" />
              ) : (
                  <MessageSquare size={24} className="text-gray-500" />
              )}
          </div>
          
          <div className="absolute top-full mt-2 left-1/2 -translate-x-1/2 bg-black/80 text-white text-xs py-1 px-3 rounded-full opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap pointer-events-none">
            Click to watch
          </div>
      </div>
  );

  // The Expanded Widget
  const ExpandedWidget = () => (
    <div 
        className={`bg-white rounded-2xl shadow-2xl overflow-hidden flex flex-col transition-all duration-300 ease-in-out relative ${config.widgetStyle === 'fixed' ? 'w-full' : ''}`}
        style={{ 
            width: `${config.videoWidth}px`,
            // If fixed, height is auto, if floating, max height constraint
            maxHeight: config.widgetStyle === 'fixed' ? 'none' : '80vh',
        }}
    >
        {/* Header (Close Button) - Only for floating */}
        {config.widgetStyle === 'floating' && (
            <button 
                onClick={(e) => { e.stopPropagation(); setIsOpen(false); }}
                className="absolute top-4 right-4 z-20 bg-black/20 hover:bg-black/40 text-white rounded-full p-1 backdrop-blur-sm transition-colors"
            >
                <X size={20} />
            </button>
        )}

        {/* Video Area */}
        <div 
            className="relative w-full bg-black cursor-pointer group shrink-0"
            style={{ aspectRatio: '9/16' }}
            onClick={isYouTubeUrl(config.videoUrl) ? undefined : togglePlay}
        >
             {/* Replaced by Form if mode is replace-video and form is active */}
             {config.ghlEnabled && config.ghlDisplayMode === 'replace-video' && showForm ? (
                 <GhlFormPlaceholder />
             ) : (
                 <>
                    {videoError ? (
                        <div className="w-full h-full flex flex-col items-center justify-center bg-gray-900 text-gray-400 p-6 text-center">
                            <AlertCircle size={32} className="mb-3 text-red-500" />
                            <p className="text-sm font-medium text-white mb-1">Video Error</p>
                            <p className="text-xs text-gray-500">The video URL could not be loaded. Please check the source link.</p>
                        </div>
                    ) : isYouTubeUrl(config.videoUrl) ? (
                        // YouTube iframe embed
                        <iframe 
                            src={config.videoUrl}
                            className="w-full h-full object-cover"
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                            allowFullScreen
                            style={{ border: 'none' }}
                        />
                    ) : (
                        <>
                            <video 
                                ref={videoRef}
                                src={config.videoUrl}
                                className="w-full h-full object-cover"
                                loop
                                muted // Default to muted to allow autoplay/preview
                                playsInline
                                onError={(e) => {
                                    console.error("Video error:", e);
                                    setVideoError(true);
                                }}
                            />
                            
                            {/* Play Button Overlay - only for regular videos */}
                            {!isPlaying && (
                                <div className="absolute inset-0 flex items-center justify-center bg-black/10 group-hover:bg-black/20 transition-colors">
                                    <div className="w-16 h-16 rounded-full bg-white/20 backdrop-blur-md flex items-center justify-center pl-1 transition-transform group-hover:scale-110">
                                        <Play fill="white" className="text-white w-8 h-8" />
                                    </div>
                                </div>
                            )}
                        </>
                    )}
                 </>
             )}
        </div>

        {/* Content Area Below Video */}
        <div className="p-4 bg-white relative border-t border-gray-100">
             {/* Slide Up Form */}
             {config.ghlEnabled && config.ghlDisplayMode === 'slide-up' && showForm && (
                 <div className="absolute bottom-0 left-0 w-full bg-white z-10 rounded-t-2xl shadow-[0_-5px_20px_rgba(0,0,0,0.1)] border-t transition-transform animate-in slide-in-from-bottom duration-300 flex flex-col max-h-[300px]">
                     <div className="flex justify-between items-center p-3 border-b shrink-0">
                         <span className="text-sm font-semibold text-gray-700">Get in touch</span>
                         <button onClick={() => setShowForm(false)} className="text-gray-400 hover:text-gray-600"><ChevronDown size={18}/></button>
                     </div>
                     <div className="overflow-y-auto p-1">
                        <GhlFormPlaceholder compact />
                     </div>
                 </div>
             )}

            {/* Buttons */}
            <div className="space-y-2 relative z-0">
                {config.buttons.map(btn => (
                    <a 
                        key={btn.id}
                        href={btn.link}
                        target={btn.openInNewTab ? "_blank" : "_self"}
                        onClick={(e) => {
                             // If GHL is enabled, let's assume the first button toggles the form for this demo if needed
                             // Or just always toggle form for demo purposes if enabled
                             if (config.ghlEnabled) {
                                e.preventDefault();
                                setShowForm(!showForm);
                             }
                        }}
                        className="block w-full text-center py-3 px-4 rounded-lg font-medium transition-transform active:scale-95 shadow-sm hover:shadow-md"
                        style={{ 
                            backgroundColor: btn.backgroundColor, 
                            color: btn.textColor 
                        }}
                    >
                        {btn.label}
                    </a>
                ))}
            </div>

            {/* Under Video Form */}
            {config.ghlEnabled && config.ghlDisplayMode === 'under-video' && (
                 <div className="mt-4 pt-4 border-t">
                     <GhlFormPlaceholder compact />
                 </div>
            )}
        </div>
    </div>
  );

  const GhlFormPlaceholder = ({ compact = false }: { compact?: boolean }) => (
      <div className={`w-full ${compact ? 'min-h-[150px]' : 'h-full min-h-[250px]'} bg-gray-50 border-2 border-dashed border-gray-200 rounded-lg flex flex-col items-center justify-center p-4 text-center`}>
          <div className="w-10 h-10 bg-indigo-100 rounded-full flex items-center justify-center mb-2 text-indigo-600 font-bold text-lg">
              HL
          </div>
          <p className="text-sm font-medium text-gray-700">Form Preview</p>
          <p className="text-xs text-gray-500 mt-1 max-w-[200px]">
             {config.ghlInputMethod === 'code' ? 'Embedded Form Code' : 'Form via ID/URL'}
          </p>
      </div>
  );

  return (
    <div className="relative w-full h-full min-h-[600px] bg-gray-800 overflow-hidden flex items-center justify-center pattern-grid-lg text-gray-300">
        {/* Background Hint */}
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            <div className="text-center opacity-10">
                <h1 className="text-5xl font-black uppercase tracking-tighter">Your Site</h1>
            </div>
        </div>

        {/* The Widget Container */}
        <div className={`${getPositionClasses()} z-50 flex flex-col items-end`}>
            {isOpen || config.widgetStyle === 'fixed' ? (
                <ExpandedWidget />
            ) : (
                config.showAvatarToggle && <AvatarBubble />
            )}
        </div>
    </div>
  );
};

export default PreviewPanel;
