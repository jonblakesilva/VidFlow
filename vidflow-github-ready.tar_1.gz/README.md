# VidFlow - Interactive Video Widget Builder

![VidFlow Demo](https://img.shields.io/badge/Status-Production%20Ready-green)
![License](https://img.shields.io/badge/License-MIT-blue)
![Framework](https://img.shields.io/badge/Framework-React%2019-61dafb)

> Create engaging floating video widgets for your GoHighLevel sites in seconds. No coding required.

**Built by [Arbor Advantage](https://arboradvantage.com)** - Marketing automation for tree service businesses earning under $100K/month.

---

## 🎯 What is VidFlow?

VidFlow is a **no-code builder** for creating interactive video widgets that capture leads on your website. Perfect for tree service businesses, home service companies, and any business using GoHighLevel.

### Key Features

- 🎥 **YouTube & MP4 Support** - Host videos anywhere, no bandwidth costs
- 🎨 **Visual Builder** - No coding required, live preview updates instantly
- 📱 **Mobile Responsive** - Works flawlessly on all devices
- 🔗 **GHL Integration** - Native form embedding with 3 display modes
- ⚡ **One-Click Deploy** - Generate embed code and download .js file
- 🎨 **Fully Customizable** - Colors, buttons, positioning, avatar images
- 🚀 **Production Ready** - Optimized bundle (73KB gzipped), zero errors

---

## 🚀 Quick Start

### Option 1: Deploy Your Own (Recommended)

1. **Deploy to Vercel** (2 minutes)
   - Click the button below
   - Connect your GitHub account
   - Deploy automatically

   [![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new/clone?repository-url=https://github.com/YOUR_USERNAME/vidflow-widget-builder)

2. **Get Your URL**
   - Copy your Vercel URL (e.g., `https://vidflow-xyz.vercel.app`)

3. **Embed in GoHighLevel**
   ```html
   <iframe 
     src="https://YOUR-VERCEL-URL.vercel.app" 
     width="100%" 
     height="100vh" 
     frameborder="0"
     allow="autoplay; fullscreen"
     style="border: none;"
   ></iframe>
   ```

### Option 2: Run Locally

```bash
# Clone the repository
git clone https://github.com/YOUR_USERNAME/vidflow-widget-builder.git
cd vidflow-widget-builder

# Install dependencies
npm install

# Start development server (opens at http://localhost:5173)
npm run dev

# Build for production
npm run build

# Preview production build
npm run preview
```

---

## 📦 Tech Stack

- **Framework:** React 19 + TypeScript
- **Styling:** Tailwind CSS (via CDN)
- **Icons:** Lucide React
- **Build Tool:** Vite 6
- **Deployment:** Vercel (recommended)
- **Bundle Size:** 246KB raw → 73KB gzipped

---

## 🎬 Perfect For

### Tree Service Businesses
- Welcome videos from company owner
- Before/after project showcases
- Emergency storm damage response
- Seasonal promotion campaigns (spring cleanup, fall trimming)
- Safety certifications and insurance proof

### Home Service Companies
- Service area demonstrations
- Customer testimonial compilations
- 24/7 availability announcements
- Special offer promotions
- Equipment and crew showcases

### Marketing Agencies
- Client lead capture widgets
- White-label solutions
- Done-for-you service offerings
- Template libraries for clients

---

## 🛠️ How It Works

1. **Configure** - Use the visual builder to customize your widget
2. **Preview** - See live updates as you make changes
3. **Generate** - Download the .js file or copy embed code
4. **Deploy** - Upload to GHL Media Library or embed directly
5. **Convert** - Start capturing leads with engaging video

---

## 📖 Documentation

- **QUICKSTART.md** - Get live in 5 minutes
- **DEPLOYMENT.md** - Detailed deployment guide
- **CHECKLIST.md** - Pre-launch verification

---

## 🌐 Deployment to Vercel

**Why Vercel?**
- ✅ Free tier (100GB bandwidth/month)
- ✅ Automatic HTTPS
- ✅ Global CDN
- ✅ Instant deployment from GitHub
- ✅ Zero configuration needed

**Deploy Steps:**
1. Push code to GitHub
2. Visit [vercel.com/new](https://vercel.com/new)
3. Import your repository
4. Click "Deploy"
5. Done! Copy your URL

---

## 🎨 Customization

### Default Configuration
The builder comes with a Rick Roll demo (because why not?). To change the default:

Edit `types.ts` line 42:
```typescript
export const INITIAL_CONFIG: WidgetConfig = {
  videoUrl: 'YOUR_VIDEO_URL', // Change this
  themeColor: '#YOUR_COLOR',   // Change this
  // ... more settings
}
```

### Widget Options
- Video width: 200-500px
- 4 position options (corners)
- 2 styles (floating/fixed)
- Up to 3 custom buttons
- Color picker for theme
- Avatar image URL
- GHL form integration

---

## 🔗 GoHighLevel Integration

### Method 1: Direct iframe Embed
Best for full-page widget builder:
```html
<iframe src="https://your-url.vercel.app" width="100%" height="100vh"></iframe>
```

### Method 2: Generated Widget Code
Users build their widget, download the .js file, upload to GHL Media Library, then:
```html
<script src="https://your-ghl-media-url/vidflow.js"></script>
```

### Method 3: Section Embed
For partial page integration:
```html
<div style="height: 800px;">
  <iframe src="https://your-url.vercel.app" width="100%" height="100%"></iframe>
</div>
```

---

## 💰 Monetization Ideas

**Done-For-You Service**
- Setup: $497 (includes custom video + widget)
- Monthly: $97 (hosting + updates)
- Margin: ~80% after costs

**SaaS Product**
- Monthly: $47/month for unlimited widgets
- Target: 200+ tree services
- Potential MRR: $9,400 at 10% adoption

**White Label**
- One-time: $2,997 (full source + branding)
- Monthly: $297 (updates + support)
- Target: Marketing agencies

**Template Packs**
- One-time: $197 per pack
- 10 pre-built widgets per pack
- Passive income stream

---

## 🤝 Contributing

Built and maintained by [Arbor Advantage](https://arboradvantage.com).

Contributions welcome! Please feel free to submit a Pull Request.

---

## 📝 License

MIT License - Free for commercial use

Copyright (c) 2025 Arbor Advantage

---

## 🙏 About Arbor Advantage

**Marketing automation platform for tree service businesses earning under $100K/month.**

We bring 7-figure operational credibility (6 years running a successful tree service) to help tree service companies scale through:
- Done-With-You services ($497-799/month)
- Done-For-You solutions ($3,997 setup + $297/month)  
- Fractional CMO services (starting at $25K + revenue share)

VidFlow is part of our toolkit to help tree service businesses engage visitors and capture more leads.

---

## 📞 Support

- **Documentation:** Check the `/docs` folder
- **Issues:** [GitHub Issues](https://github.com/YOUR_USERNAME/vidflow-widget-builder/issues)
- **Website:** [arboradvantage.com](https://arboradvantage.com)

---

**Made with ❤️ for tree service businesses**

*Because even tree services deserve engaging video widgets* 🌲
