
import React, { useState } from 'react';
import { WidgetConfig } from '../types';
import { Copy, Check, AlertTriangle, Download, FileJson, FileCode } from 'lucide-react';

interface CodeGeneratorProps {
  config: WidgetConfig;
}

const CodeGenerator: React.FC<CodeGeneratorProps> = ({ config }) => {
  const [copied, setCopied] = useState(false);
  const [activeTab, setActiveTab] = useState<'inline' | 'file'>('file');

  const isGhlInvalid = config.ghlEnabled && (
      (config.ghlInputMethod === 'code' && !config.ghlEmbedCode.trim()) ||
      (config.ghlInputMethod === 'id_url' && !config.ghlFormIdOrUrl.trim())
  );

  const getRuntimeScript = (configJson: string) => `
(function() {
  const cfg = ${configJson};
  if (!cfg.videoUrl) return;

  function el(t, c, i) {
    const e = document.createElement(t);
    if (c) e.className = c;
    if (i) e.innerHTML = i;
    return e;
  }

  function getYT(url) {
    const regex = /(?:youtube\\.com\\/(?:[^\\/]+\\/.+\\/|(?:v|e(?:mbed)?|shorts)\\/|.*[?&]v=)|youtu\\.be\\/)([^"&?\\/\\s]{11})/;
    const match = url.match(regex);
    return match ? match[1] : null;
  }

  const styles = \`
    .vv-root {
      position: fixed; z-index: 99999; 
      display: flex; flex-direction: column; 
      font-family: system-ui, -apple-system, sans-serif;
      transition: all 0.5s cubic-bezier(0.16, 1, 0.3, 1);
      visibility: hidden; opacity: 0;
    }
    .vv-root.visible { visibility: visible; opacity: 1; }
    
    .vv-pos-bottom-right { bottom: 20px; right: 20px; align-items: flex-end; }
    .vv-pos-bottom-left { bottom: 20px; left: 20px; align-items: flex-start; }
    .vv-pos-top-right { top: 20px; right: 20px; align-items: flex-end; }
    .vv-pos-top-left { top: 20px; left: 20px; align-items: flex-start; }

    .vv-bubble {
      width: 64px; height: 64px; border-radius: 50%; border: 3px solid \${cfg.themeColor};
      background: #fff; cursor: pointer; overflow: hidden; box-shadow: 0 8px 25px rgba(0,0,0,0.15);
      transition: transform 0.3s ease; position: relative; margin-top: 10px;
    }
    .vv-bubble:hover { transform: scale(1.08) rotate(3deg); }
    .vv-bubble img { width: 100%; height: 100%; object-fit: cover; }
    .vv-badge { position: absolute; top: 0; right: 0; width: 14px; height: 14px; background: #ef4444; border: 2px solid #fff; border-radius: 50%; }

    .vv-welcome-msg {
      position: absolute; bottom: 75px; right: 0; background: #fff; padding: 6px 12px; border-radius: 12px;
      font-size: 10px; font-weight: 800; box-shadow: 0 4px 15px rgba(0,0,0,0.1); border: 1px solid #eee;
      white-space: nowrap; animation: vv-float 2s infinite ease-in-out;
    }
    @keyframes vv-float { 0%, 100% { transform: translateY(0); } 50% { transform: translateY(-5px); } }

    .vv-window {
      width: \${cfg.videoWidth}px; max-width: 90vw; background: #fff; border-radius: 20px; overflow: hidden;
      box-shadow: 0 25px 50px -12px rgba(0,0,0,0.25); display: none; flex-direction: column;
      transform: translateY(20px); transition: all 0.4s ease;
    }
    .vv-window.active { display: flex; transform: translateY(0); }

    .vv-video-container { position: relative; width: 100%; aspect-ratio: 9/16; background: #000; cursor: pointer; }
    .vv-video-container video, .vv-video-container iframe { width: 100%; height: 100%; object-fit: cover; border: none; }
    
    .vv-overlay { position: absolute; inset: 0; display: flex; items: center; justify-content: center; background: rgba(0,0,0,0.1); }
    .vv-play-btn { width: 50px; height: 50px; background: rgba(255,255,255,0.2); backdrop-filter: blur(5px); border-radius: 50%; display: flex; items: center; justify-content: center; }
    .vv-play-btn::after { content: ''; border-style: solid; border-width: 10px 0 10px 15px; border-color: transparent transparent transparent #fff; margin-left: 5px; }
    
    .vv-unmute-btn {
      position: absolute; bottom: 15px; left: 15px; background: rgba(0,0,0,0.6); color: #fff; padding: 6px 12px;
      border-radius: 20px; font-size: 10px; font-weight: 800; border: 1px solid rgba(255,255,255,0.2);
      backdrop-filter: blur(4px); display: none;
    }
    .vv-unmute-btn.visible { display: block; }

    .vv-close { position: absolute; top: 12px; right: 12px; width: 28px; height: 28px; background: rgba(0,0,0,0.2); border-radius: 50%; border: none; color: #fff; cursor: pointer; font-size: 18px; display: flex; items: center; justify-content: center; z-index: 10; }

    .vv-body { padding: 15px; }
    .vv-btn { display: block; width: 100%; padding: 12px; margin-bottom: 8px; border-radius: 10px; text-decoration: none; text-align: center; font-weight: 700; font-size: 14px; transition: opacity 0.2s; }
    .vv-btn:hover { opacity: 0.9; }
    
    .vv-gdpr { font-size: 10px; color: #999; text-align: center; margin-top: 8px; }

    @keyframes vv-bounce { 0%, 100% { transform: translateY(0); } 50% { transform: translateY(-10px); } }
    .vv-anim-bounce { animation: vv-bounce 2s infinite; }
  \`;

  const s = document.createElement('style'); s.innerHTML = styles; document.head.appendChild(s);

  function setCookie(n, v, d) {
    const e = new Date(); e.setTime(e.getTime() + (d*24*60*60*1000));
    document.cookie = n + "=" + v + ";expires=" + e.toUTCString() + ";path=/";
  }
  function getCookie(n) {
    const b = "; " + document.cookie; const p = b.split("; " + n + "=");
    if (p.length === 2) return p.pop().split(";").shift();
  }

  const root = el('div', 'vv-root vv-pos-' + cfg.position);
  document.body.appendChild(root);

  const win = el('div', 'vv-window');
  root.appendChild(win);

  const ytId = getYT(cfg.videoUrl);
  const vCont = el('div', 'vv-video-container');
  let vid;

  if (ytId) {
    vid = document.createElement('iframe');
    vid.src = 'https://www.youtube.com/embed/' + ytId + '?autoplay=1&mute=' + (cfg.autoplayMuted ? '1' : '0') + '&controls=0&loop=1&playlist=' + ytId + '&modestbranding=1&rel=0&enablejsapi=1&origin=' + window.location.origin;
    vid.allow = "autoplay; encrypted-media";
  } else {
    vid = document.createElement('video');
    vid.src = cfg.videoUrl;
    if (cfg.showThumbnail && cfg.videoThumbnailUrl) vid.poster = cfg.videoThumbnailUrl;
    vid.loop = true; vid.playsInline = true; vid.muted = cfg.autoplayMuted;
  }
  vCont.appendChild(vid);
  
  if (cfg.showCloseButton) {
    const cls = el('button', 'vv-close', '&times;');
    cls.onclick = (e) => { e.stopPropagation(); toggle(false); };
    win.appendChild(cls);
  }

  const playO = el('div', 'vv-overlay', '<div class="vv-play-btn"></div>');
  if (!ytId) vCont.appendChild(playO);
  
  const unmuteBtn = el('button', 'vv-unmute-btn', 'TAP FOR SOUND');
  if (!ytId) {
    unmuteBtn.onclick = (e) => { e.stopPropagation(); vid.muted = false; unmuteBtn.classList.remove('visible'); };
    vCont.appendChild(unmuteBtn);
  }
  
  win.appendChild(vCont);

  const body = el('div', 'vv-body');
  win.appendChild(body);

  if (cfg.buttons) cfg.buttons.forEach(b => {
    const a = el('a', 'vv-btn', b.label);
    a.href = b.link; a.style.background = b.backgroundColor; a.style.color = b.textColor;
    if (b.openInNewTab) a.target = '_blank';
    a.onclick = () => { if (cfg.sessionPersistenceEnabled) setCookie('vv_engaged', '1', 1); };
    body.appendChild(a);
  });

  if (cfg.gdprEnabled) body.appendChild(el('div', 'vv-gdpr', cfg.gdprText));

  let bubble;
  if (cfg.showAvatarToggle) {
    bubble = el('div', 'vv-bubble' + (cfg.entranceAnimation === 'bounce' ? ' vv-anim-bounce' : ''));
    if (cfg.avatarUrl && cfg.avatarUrl.trim() !== '') {
      bubble.innerHTML = '<img src="'+cfg.avatarUrl+'"><div class="vv-badge"></div>';
    } else {
      bubble.innerHTML = '<div style="display:flex;align-items:center;justify-content:center;height:100%;color:#666"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path></svg></div><div class="vv-badge"></div>';
    }
    
    if (cfg.sessionPersistenceEnabled && getCookie('vv_engaged')) {
      const msg = el('div', 'vv-welcome-msg', cfg.welcomeBackMessage);
      bubble.appendChild(msg);
    }
    
    bubble.onclick = () => toggle(true);
    root.appendChild(bubble);
  }

  let isOpen = false;
  function toggle(o) {
    isOpen = o;
    if (o) {
        win.classList.add('active');
        if (bubble) bubble.style.display = 'none';
        if (!ytId) {
          vid.play().catch(() => {});
          if (vid.muted) unmuteBtn.classList.add('visible');
          playO.style.display = 'none';
        }
        if (cfg.sessionPersistenceEnabled) setCookie('vv_seen', '1', 1);
    } else {
        win.classList.remove('active');
        if (bubble) bubble.style.display = 'block';
        if (!ytId) {
          vid.pause();
          playO.style.display = 'flex';
        }
    }
  }

  if (!ytId) {
    vCont.onclick = () => vid.paused ? (vid.play(), playO.style.display='none', vid.muted ? unmuteBtn.classList.add('visible') : null) : (vid.pause(), playO.style.display='flex');
  }

  let launched = false;
  function launch() {
    if (launched) return;
    launched = true;
    root.classList.add('visible');
    if (cfg.widgetStyle === 'fixed' || cfg.startExpanded) toggle(true);
  }

  if (cfg.exitPopEnabled) {
    document.addEventListener('mouseleave', (e) => {
      if (e.clientY <= 5 && !isOpen) {
        toggle(true);
      }
    });
  }

  setTimeout(() => {
    if (!cfg.exitPopEnabled) launch();
  }, (cfg.displayDelay || 0) * 1000);

})();
`;

  const getCleanConfig = () => {
    return {
        videoUrl: config.videoUrl,
        videoThumbnailUrl: config.videoThumbnailUrl,
        showThumbnail: config.showThumbnail,
        videoWidth: config.videoWidth,
        themeColor: config.themeColor,
        avatarUrl: config.avatarUrl,
        showAvatarToggle: config.showAvatarToggle,
        startExpanded: config.startExpanded,
        widgetStyle: config.widgetStyle,
        position: config.position,
        entranceAnimation: config.entranceAnimation,
        displayDelay: config.displayDelay,
        showCloseButton: config.showCloseButton,
        gdprEnabled: config.gdprEnabled,
        gdprText: config.gdprText,
        exitPopEnabled: config.exitPopEnabled,
        sessionPersistenceEnabled: config.sessionPersistenceEnabled,
        welcomeBackMessage: config.welcomeBackMessage,
        autoplayMuted: config.autoplayMuted,
        buttons: config.buttons.map(b => ({
            label: b.label,
            link: b.link,
            backgroundColor: b.backgroundColor,
            textColor: b.textColor,
            openInNewTab: b.openInNewTab
        })),
        ghlEnabled: config.ghlEnabled,
        ghlInputMethod: config.ghlInputMethod,
        ghlEmbedCode: config.ghlEmbedCode,
        ghlFormIdOrUrl: config.ghlFormIdOrUrl,
        ghlDisplayMode: config.ghlDisplayMode,
    };
  };

  const handleDownload = () => {
    const configJson = JSON.stringify(getCleanConfig(), null, 2);
    const fileContent = getRuntimeScript(configJson);
    const blob = new Blob([fileContent], { type: 'text/javascript' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'vidflow.js';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleCopy = () => {
    if (isGhlInvalid) return;
    const code = activeTab === 'file' 
      ? `<!-- VidFlow Widget (Self-Hosted) -->\n<script src="YOUR_UPLOADED_SCRIPT_URL_HERE"></script>`
      : `<!-- VidFlow Widget (Inline) -->\n<script>\n${getRuntimeScript(JSON.stringify(getCleanConfig()))}\n</script>`;
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="bg-gray-900 rounded-3xl overflow-hidden border border-white/10 shadow-2xl">
      <div className="flex border-b border-white/5">
        <button 
          onClick={() => setActiveTab('file')}
          className={`flex-1 py-4 text-xs font-black uppercase tracking-widest ${activeTab === 'file' ? 'bg-indigo-600 text-white' : 'text-gray-500 hover:text-white transition-colors'}`}
        >
          1. Download File
        </button>
        <button 
          onClick={() => setActiveTab('inline')}
          className={`flex-1 py-4 text-xs font-black uppercase tracking-widest ${activeTab === 'inline' ? 'bg-indigo-600 text-white' : 'text-gray-500 hover:text-white transition-colors'}`}
        >
          2. Inline Code
        </button>
      </div>

      <div className="p-6">
        <div className="flex justify-between items-center mb-6">
          <p className="text-xs text-gray-400">
            {activeTab === 'file' 
              ? "Recommended for best site performance and easier updates." 
              : "Best for quick testing or limited site access."}
          </p>
          {activeTab === 'file' && (
            <button onClick={handleDownload} className="bg-white text-black px-4 py-2 rounded-full text-xs font-bold hover:bg-indigo-100 transition-colors flex items-center">
              <Download size={14} className="mr-2" /> Download JS
            </button>
          )}
        </div>

        <div className="relative group">
          <button 
            onClick={handleCopy}
            className="absolute top-3 right-3 z-10 bg-white/10 hover:bg-white/20 text-white px-3 py-1.5 rounded-lg text-[10px] font-bold backdrop-blur-md transition-all border border-white/10"
          >
            {copied ? <Check size={12} className="inline mr-1" /> : <Copy size={12} className="inline mr-1" />}
            {copied ? 'COPIED' : 'COPY'}
          </button>
          <div className="bg-black/50 p-4 rounded-xl font-mono text-[10px] text-indigo-300 overflow-x-auto h-32 border border-white/5">
            {activeTab === 'file' 
              ? `<!-- VidFlow (Self-Hosted) -->\n<script src="YOUR_UPLOADED_SCRIPT_URL_HERE"></script>`
              : getRuntimeScript(JSON.stringify(getCleanConfig()))}
          </div>
        </div>

        {activeTab === 'file' && (
          <div className="mt-4 flex items-start space-x-3 p-3 bg-indigo-900/20 border border-indigo-500/20 rounded-xl">
            <AlertTriangle size={16} className="text-indigo-400 shrink-0" />
            <p className="text-[10px] text-indigo-200">
              Upload <code className="bg-indigo-900/50 px-1">vidflow.js</code> to your <strong>GHL Media Library</strong>, copy the link, and replace the placeholder above.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default CodeGenerator;
