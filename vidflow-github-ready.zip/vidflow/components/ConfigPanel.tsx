
import React, { useState } from 'react';
import { Plus, Trash2, Settings, Palette, Share2, ShieldCheck, Clock, Layers, MousePointer2, UserCheck, VolumeX, Image, Maximize2, Minimize2, MapPin } from 'lucide-react';
import { WidgetConfig, WidgetPosition, WidgetStyle, GhlInputMethod, GhlDisplayMode, GhlSuccessAction, OverlayButton, EntranceAnimation } from '../types';

interface ConfigPanelProps {
  config: WidgetConfig;
  onChange: (newConfig: WidgetConfig) => void;
}

const ConfigPanel: React.FC<ConfigPanelProps> = ({ config, onChange }) => {
  const [activeTab, setActiveTab] = useState<'design' | 'buttons' | 'ghl' | 'advanced'>('design');
  
  const handleChange = <K extends keyof WidgetConfig>(key: K, value: WidgetConfig[K]) => {
    onChange({ ...config, [key]: value });
  };

  const handleButtonChange = (id: string, field: keyof OverlayButton, value: any) => {
    const newButtons = config.buttons.map(btn => 
      btn.id === id ? { ...btn, [field]: value } : btn
    );
    handleChange('buttons', newButtons);
  };

  const addButton = () => {
    if (config.buttons.length >= 3) return;
    const newButton: OverlayButton = {
      id: crypto.randomUUID(),
      label: 'New Button',
      link: 'https://arboradvantage.com',
      backgroundColor: config.themeColor,
      textColor: '#ffffff',
      openInNewTab: true
    };
    handleChange('buttons', [...config.buttons, newButton]);
  };

  const removeButton = (id: string) => {
    handleChange('buttons', config.buttons.filter(b => b.id !== id));
  };

  return (
    <div className="space-y-6">
      <div className="flex bg-gray-100 p-1 rounded-xl overflow-x-auto no-scrollbar">
        {[
          { id: 'design', icon: Palette, label: 'Design' },
          { id: 'buttons', icon: Layers, label: 'Buttons' },
          { id: 'ghl', icon: Share2, label: 'GHL' },
          { id: 'advanced', icon: Settings, label: 'Advanced' }
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`flex-1 flex items-center justify-center space-x-2 px-3 py-2 rounded-lg text-xs font-bold transition-all whitespace-nowrap ${
              activeTab === tab.id ? 'bg-white text-indigo-600 shadow-sm' : 'text-gray-500 hover:bg-white/50'
            }`}
          >
            <tab.icon size={14} />
            <span>{tab.label}</span>
          </button>
        ))}
      </div>

      {activeTab === 'design' && (
        <div className="space-y-4 animate-in fade-in slide-in-from-left-2 duration-300">
          <div className="space-y-2">
            <label className="text-xs font-bold text-gray-400 uppercase">Video Source (YouTube or MP4)</label>
            <input
              type="text"
              value={config.videoUrl}
              onChange={(e) => handleChange('videoUrl', e.target.value)}
              className="w-full px-3 py-2 bg-gray-50 border border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500"
              placeholder="YouTube URL or Direct MP4"
            />
          </div>

          <div className="space-y-2">
            <div className="flex justify-between items-center">
              <label className="text-xs font-bold text-gray-400 uppercase">Video Thumbnail</label>
              <div className="flex items-center space-x-2">
                <span className="text-[10px] text-gray-400 font-bold">ENABLE</span>
                <button 
                  onClick={() => handleChange('showThumbnail', !config.showThumbnail)}
                  className={`w-8 h-4 rounded-full relative transition-colors ${config.showThumbnail ? 'bg-indigo-600' : 'bg-gray-300'}`}
                >
                  <div className={`absolute top-0.5 w-3 h-3 bg-white rounded-full transition-all ${config.showThumbnail ? 'right-0.5' : 'left-0.5'}`} />
                </button>
              </div>
            </div>
            <input
              type="text"
              value={config.videoThumbnailUrl}
              onChange={(e) => handleChange('videoThumbnailUrl', e.target.value)}
              disabled={!config.showThumbnail}
              className={`w-full px-3 py-2 bg-gray-50 border border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500 ${!config.showThumbnail ? 'opacity-50 cursor-not-allowed' : ''}`}
              placeholder="Image URL for video cover"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2">
              <label className="text-xs font-bold text-gray-400 uppercase">Width (px)</label>
              <input
                type="number"
                value={config.videoWidth}
                onChange={(e) => handleChange('videoWidth', Number(e.target.value))}
                className="w-full px-3 py-2 bg-gray-50 border border-gray-200 rounded-lg text-sm"
              />
            </div>
            <div className="space-y-2">
              <label className="text-xs font-bold text-gray-400 uppercase">Theme</label>
              <div className="flex items-center bg-gray-50 border border-gray-200 rounded-lg p-1">
                <input
                  type="color"
                  value={config.themeColor}
                  onChange={(e) => handleChange('themeColor', e.target.value)}
                  className="w-8 h-8 rounded border-none bg-transparent cursor-pointer"
                />
                <span className="text-xs font-mono ml-2 text-gray-500 uppercase">{config.themeColor}</span>
              </div>
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-xs font-bold text-gray-400 uppercase">Widget Position</label>
            <div className="grid grid-cols-2 gap-2">
              {[
                { id: 'top-left', label: 'Top Left' },
                { id: 'top-right', label: 'Top Right' },
                { id: 'bottom-left', label: 'Bottom Left' },
                { id: 'bottom-right', label: 'Bottom Right' }
              ].map(pos => (
                <button
                  key={pos.id}
                  onClick={() => handleChange('position', pos.id as WidgetPosition)}
                  className={`flex items-center justify-center space-x-2 py-2 border rounded-lg text-xs font-bold transition-all ${
                    config.position === pos.id 
                      ? 'bg-indigo-50 border-indigo-500 text-indigo-700' 
                      : 'bg-white border-gray-200 text-gray-500 hover:border-gray-300'
                  }`}
                >
                  <MapPin size={12} />
                  <span>{pos.label}</span>
                </button>
              ))}
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-xs font-bold text-gray-400 uppercase">Avatar Image (Optional)</label>
            <input
              type="text"
              value={config.avatarUrl}
              onChange={(e) => handleChange('avatarUrl', e.target.value)}
              className="w-full px-3 py-2 bg-gray-50 border border-gray-200 rounded-lg text-sm"
              placeholder="Leave empty for default icon"
            />
          </div>

          <div className="grid grid-cols-1 gap-3 pt-2">
            <div className="flex items-center justify-between p-3 bg-gray-50 rounded-xl border border-gray-200">
              <div className="flex items-center space-x-2">
                <Minimize2 size={14} className="text-gray-600" />
                <span className="text-xs font-bold text-gray-700">Show Bubble Initially</span>
              </div>
              <button 
                onClick={() => handleChange('showAvatarToggle', !config.showAvatarToggle)}
                className={`w-10 h-5 rounded-full transition-colors relative ${config.showAvatarToggle ? 'bg-indigo-600' : 'bg-gray-300'}`}
              >
                <div className={`absolute top-1 w-3 h-3 bg-white rounded-full transition-all ${config.showAvatarToggle ? 'right-1' : 'left-1'}`} />
              </button>
            </div>

            <div className="flex items-center justify-between p-3 bg-gray-50 rounded-xl border border-gray-200">
              <div className="flex items-center space-x-2">
                <Maximize2 size={14} className="text-gray-600" />
                <span className="text-xs font-bold text-gray-700">Start Expanded (Big)</span>
              </div>
              <button 
                onClick={() => handleChange('startExpanded', !config.startExpanded)}
                className={`w-10 h-5 rounded-full transition-colors relative ${config.startExpanded ? 'bg-indigo-600' : 'bg-gray-300'}`}
              >
                <div className={`absolute top-1 w-3 h-3 bg-white rounded-full transition-all ${config.startExpanded ? 'right-1' : 'left-1'}`} />
              </button>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'buttons' && (
        <div className="space-y-4 animate-in fade-in slide-in-from-left-2 duration-300">
          <div className="flex justify-between items-center">
            <h4 className="text-xs font-bold text-gray-400 uppercase">Call to Actions</h4>
            <span className="text-[10px] font-bold bg-gray-100 px-2 py-0.5 rounded-full">{config.buttons.length}/3</span>
          </div>
          
          <div className="space-y-3">
            {config.buttons.map((btn, i) => (
              <div key={btn.id} className="p-3 bg-gray-50 rounded-xl border border-gray-200 space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-[10px] font-black text-gray-300 uppercase">Button {i+1}</span>
                  <button onClick={() => removeButton(btn.id)} className="text-gray-300 hover:text-red-500"><Trash2 size={14}/></button>
                </div>
                <input 
                  type="text" 
                  value={btn.label} 
                  onChange={(e) => handleButtonChange(btn.id, 'label', e.target.value)}
                  className="w-full px-3 py-1.5 bg-white border border-gray-100 rounded text-xs focus:ring-1 focus:ring-indigo-500 outline-none"
                  placeholder="Button Label"
                />
                <input 
                  type="text" 
                  value={btn.link} 
                  onChange={(e) => handleButtonChange(btn.id, 'link', e.target.value)}
                  className="w-full px-3 py-1.5 bg-white border border-gray-100 rounded text-xs focus:ring-1 focus:ring-indigo-500 outline-none"
                  placeholder="URL Link"
                />
              </div>
            ))}

            {config.buttons.length < 3 && (
              <button 
                onClick={addButton}
                className="w-full py-3 border-2 border-dashed border-gray-200 rounded-xl text-gray-400 hover:text-indigo-600 hover:border-indigo-600 text-xs font-bold flex items-center justify-center transition-all"
              >
                <Plus size={14} className="mr-2" /> Add Button
              </button>
            )}
          </div>
        </div>
      )}

      {activeTab === 'ghl' && (
        <div className="space-y-4 animate-in fade-in slide-in-from-left-2 duration-300">
          <div className="flex items-center justify-between p-3 bg-indigo-50 rounded-xl border border-indigo-100">
            <div className="flex items-center space-x-2">
              <Share2 size={16} className="text-indigo-600" />
              <span className="text-sm font-bold text-indigo-900">Enable GHL Integration</span>
            </div>
            <button 
              onClick={() => handleChange('ghlEnabled', !config.ghlEnabled)}
              className={`w-10 h-5 rounded-full transition-colors relative ${config.ghlEnabled ? 'bg-indigo-600' : 'bg-gray-300'}`}
            >
              <div className={`absolute top-1 w-3 h-3 bg-white rounded-full transition-all ${config.ghlEnabled ? 'right-1' : 'left-1'}`} />
            </button>
          </div>

          {config.ghlEnabled && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-2 bg-gray-100 p-1 rounded-lg">
                <button 
                  onClick={() => handleChange('ghlInputMethod', 'code')}
                  className={`py-1.5 text-[10px] font-bold rounded-md ${config.ghlInputMethod === 'code' ? 'bg-white shadow text-indigo-600' : 'text-gray-500'}`}
                >CODE</button>
                <button 
                  onClick={() => handleChange('ghlInputMethod', 'id_url')}
                  className={`py-1.5 text-[10px] font-bold rounded-md ${config.ghlInputMethod === 'id_url' ? 'bg-white shadow text-indigo-600' : 'text-gray-500'}`}
                >ID / URL</button>
              </div>

              {config.ghlInputMethod === 'code' ? (
                <textarea 
                  rows={3}
                  value={config.ghlEmbedCode}
                  onChange={(e) => handleChange('ghlEmbedCode', e.target.value)}
                  className="w-full px-3 py-2 bg-gray-50 border border-gray-200 rounded-lg text-[10px] font-mono"
                  placeholder="Paste GHL Form Embed Code..."
                />
              ) : (
                <input 
                  type="text"
                  value={config.ghlFormIdOrUrl}
                  onChange={(e) => handleChange('ghlFormIdOrUrl', e.target.value)}
                  className="w-full px-3 py-2 bg-gray-50 border border-gray-200 rounded-lg text-sm"
                  placeholder="Form URL or ID"
                />
              )}

              <div className="space-y-1">
                <label className="text-[10px] font-bold text-gray-400 uppercase">Display Mode</label>
                <select 
                  value={config.ghlDisplayMode}
                  onChange={(e) => handleChange('ghlDisplayMode', e.target.value as GhlDisplayMode)}
                  className="w-full px-3 py-2 bg-gray-50 border border-gray-200 rounded-lg text-xs"
                >
                  <option value="slide-up">Slide-up Overlay</option>
                  <option value="under-video">Inline (Below Video)</option>
                  <option value="replace-video">Replace Video</option>
                </select>
              </div>
            </div>
          )}
        </div>
      )}

      {activeTab === 'advanced' && (
        <div className="space-y-4 animate-in fade-in slide-in-from-left-2 duration-300">
          <div className="grid grid-cols-2 gap-3">
             <div className="space-y-1">
                <label className="text-[10px] font-bold text-gray-400 uppercase">Entrance</label>
                <select 
                  value={config.entranceAnimation}
                  onChange={(e) => handleChange('entranceAnimation', e.target.value as EntranceAnimation)}
                  className="w-full px-3 py-2 bg-gray-50 border border-gray-200 rounded-lg text-xs"
                >
                  <option value="slide-up">Slide Up</option>
                  <option value="fade-in">Fade In</option>
                  <option value="bounce">Bounce</option>
                  <option value="none">None</option>
                </select>
              </div>
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-gray-400 uppercase">Delay (sec)</label>
                <input 
                  type="number"
                  value={config.displayDelay}
                  onChange={(e) => handleChange('displayDelay', Number(e.target.value))}
                  className="w-full px-3 py-2 bg-gray-50 border border-gray-200 rounded-lg text-xs"
                />
              </div>
          </div>

          <div className="space-y-3 pt-2">
             <div className="flex items-center justify-between p-3 bg-gray-50 rounded-xl border border-gray-200">
                <div className="flex items-center space-x-2">
                   <MousePointer2 size={14} className="text-gray-600" />
                   <span className="text-xs font-bold text-gray-700">Exit Pop Trigger</span>
                </div>
                <button 
                  onClick={() => handleChange('exitPopEnabled', !config.exitPopEnabled)}
                  className={`w-8 h-4 rounded-full relative transition-colors ${config.exitPopEnabled ? 'bg-indigo-600' : 'bg-gray-300'}`}
                >
                  <div className={`absolute top-0.5 w-3 h-3 bg-white rounded-full transition-all ${config.exitPopEnabled ? 'right-0.5' : 'left-0.5'}`} />
                </button>
             </div>

             <div className="flex items-center justify-between p-3 bg-gray-50 rounded-xl border border-gray-200">
                <div className="flex items-center space-x-2">
                   <UserCheck size={14} className="text-gray-600" />
                   <span className="text-xs font-bold text-gray-700">24hr Persistence</span>
                </div>
                <button 
                  onClick={() => handleChange('sessionPersistenceEnabled', !config.sessionPersistenceEnabled)}
                  className={`w-8 h-4 rounded-full relative transition-colors ${config.sessionPersistenceEnabled ? 'bg-indigo-600' : 'bg-gray-300'}`}
                >
                  <div className={`absolute top-0.5 w-3 h-3 bg-white rounded-full transition-all ${config.sessionPersistenceEnabled ? 'right-0.5' : 'left-0.5'}`} />
                </button>
             </div>
             {config.sessionPersistenceEnabled && (
               <div className="space-y-1">
                 <label className="text-[10px] font-bold text-gray-400 uppercase">Welcome Back Message</label>
                 <input 
                   type="text" 
                   value={config.welcomeBackMessage}
                   onChange={(e) => handleChange('welcomeBackMessage', e.target.value)}
                   className="w-full px-3 py-2 bg-white border border-gray-200 rounded-lg text-xs focus:ring-2 focus:ring-indigo-500 outline-none shadow-sm"
                   placeholder="Welcome back message..."
                 />
               </div>
             )}

             <div className="flex items-center justify-between p-3 bg-gray-50 rounded-xl border border-gray-200">
                <div className="flex items-center space-x-2">
                   <VolumeX size={14} className="text-gray-600" />
                   <span className="text-xs font-bold text-gray-700">Muted Autoplay</span>
                </div>
                <button 
                  onClick={() => handleChange('autoplayMuted', !config.autoplayMuted)}
                  className={`w-8 h-4 rounded-full relative transition-colors ${config.autoplayMuted ? 'bg-indigo-600' : 'bg-gray-300'}`}
                >
                  <div className={`absolute top-0.5 w-3 h-3 bg-white rounded-full transition-all ${config.autoplayMuted ? 'right-0.5' : 'left-0.5'}`} />
                </button>
             </div>
          </div>

          <div className="p-3 bg-gray-50 rounded-xl border border-gray-200 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <ShieldCheck size={14} className="text-green-600" />
                <span className="text-xs font-bold text-gray-700">GDPR Compliance</span>
              </div>
              <button 
                onClick={() => handleChange('gdprEnabled', !config.gdprEnabled)}
                className={`w-8 h-4 rounded-full relative transition-colors ${config.gdprEnabled ? 'bg-green-600' : 'bg-gray-300'}`}
              >
                <div className={`absolute top-0.5 w-3 h-3 bg-white rounded-full transition-all ${config.gdprEnabled ? 'right-0.5' : 'left-0.5'}`} />
              </button>
            </div>
            {config.gdprEnabled && (
              <textarea 
                value={config.gdprText}
                onChange={(e) => handleChange('gdprText', e.target.value)}
                className="w-full p-2 bg-white border border-gray-100 rounded text-[10px]"
                rows={2}
              />
            )}
          </div>

          <div className="flex items-center space-x-2 pt-2">
            <input
              type="checkbox"
              id="closeBtnToggle"
              checked={config.showCloseButton}
              onChange={(e) => handleChange('showCloseButton', e.target.checked)}
              className="rounded text-indigo-600"
            />
            <label htmlFor="closeBtnToggle" className="text-xs font-medium text-gray-700">Allow users to close widget</label>
          </div>
        </div>
      )}
    </div>
  );
};

export default ConfigPanel;
