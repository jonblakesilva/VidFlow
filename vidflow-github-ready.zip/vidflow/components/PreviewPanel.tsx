
import React, { useState, useEffect, useRef } from 'react';
import { WidgetConfig } from '../types';
import { X, Play, MessageSquare, ChevronDown, AlertCircle, ArrowLeft, Send, VolumeX, Volume2 } from 'lucide-react';

interface PreviewPanelProps {
  config: WidgetConfig;
  floatingMode?: boolean;
}

const PreviewPanel: React.FC<PreviewPanelProps> = ({ config, floatingMode = false }) => {
  const [isOpen, setIsOpen] = useState(config.startExpanded);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(config.autoplayMuted);
  const [showForm, setShowForm] = useState(false);
  const [videoError, setVideoError] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);

  // Improved YouTube ID extraction to handle various URL formats (shorts, watch, embed, mobile)
  const getYoutubeId = (url: string) => {
    if (!url) return null;
    const regex = /(?:youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?|shorts)\/|.*[?&]v=)|youtu\.be\/)([^"&?\/\s]{11})/;
    const match = url.match(regex);
    return match ? match[1] : null;
  };

  const youtubeId = getYoutubeId(config.videoUrl);

  // Sync state with config
  useEffect(() => {
    if (!floatingMode) {
       setIsOpen(config.startExpanded);
    }
  }, [config.startExpanded, floatingMode]);

  // Exit Pop Logic
  useEffect(() => {
    if (!config.exitPopEnabled || !floatingMode) return;
    
    const handleMouseLeave = (e: MouseEvent) => {
      // Logic to trigger when cursor leaves top of window (common exit intent pattern)
      if (e.clientY <= 5 && !isOpen) {
        setIsOpen(true);
        setIsPlaying(true);
      }
    };
    
    document.addEventListener('mouseleave', handleMouseLeave);
    return () => document.removeEventListener('mouseleave', handleMouseLeave);
  }, [config.exitPopEnabled, isOpen, floatingMode]);

  // Handle video logic reset
  useEffect(() => {
    setVideoError(false);
    setIsPlaying(false);
    setShowForm(false);
    setIsMuted(config.autoplayMuted);
    
    // For direct MP4s, trigger load
    if (videoRef.current && !youtubeId) {
        videoRef.current.load();
    }
  }, [config.videoUrl, config.videoThumbnailUrl, config.showThumbnail, config.ghlEnabled, config.ghlDisplayMode, config.autoplayMuted, youtubeId]);

  // Handle Autoplay for direct MP4
  useEffect(() => {
    if (isOpen && videoRef.current && config.autoplayMuted && !youtubeId) {
      const playPromise = videoRef.current.play();
      if (playPromise !== undefined) {
        playPromise
          .then(() => setIsPlaying(true))
          .catch((err) => {
            console.warn("Autoplay blocked or failed:", err);
          });
      }
    }
  }, [isOpen, config.videoUrl, youtubeId, config.autoplayMuted]);

  const togglePlay = () => {
    // If it's a YouTube video, the user interacts with the iframe directly
    if (youtubeId) return;
    if (videoError || (config.ghlEnabled && config.ghlDisplayMode === 'replace-video' && showForm)) return;
    
    if (videoRef.current) {
        if (isPlaying) {
            videoRef.current.pause();
            setIsPlaying(false);
        } else {
            videoRef.current.muted = isMuted;
            const playPromise = videoRef.current.play();
            if (playPromise !== undefined) {
                playPromise.then(() => setIsPlaying(true)).catch(() => {
                    if(videoRef.current) {
                        videoRef.current.muted = true;
                        videoRef.current.play();
                        setIsPlaying(true);
                        setIsMuted(true);
                    }
                });
            }
        }
    }
  };

  const toggleMute = (e: React.MouseEvent) => {
    e.stopPropagation();
    const nextMute = !isMuted;
    setIsMuted(nextMute);
    if (videoRef.current) {
      videoRef.current.muted = nextMute;
    }
  };

  useEffect(() => {
      if (!isOpen) {
          setShowForm(false);
          setIsPlaying(false);
          if (videoRef.current) {
              videoRef.current.pause();
              videoRef.current.currentTime = 0;
          }
      }
  }, [isOpen]);

  const getPositionClasses = () => {
    if (config.widgetStyle === 'fixed' && !floatingMode) return 'relative mx-auto';
    
    switch (config.position) {
        case 'bottom-right': return 'absolute bottom-6 right-6';
        case 'bottom-left': return 'absolute bottom-6 left-6';
        case 'top-right': return 'absolute top-6 right-6';
        case 'top-left': return 'absolute top-6 left-6';
        default: return 'absolute bottom-6 right-6';
    }
  };

  const AvatarBubble = () => (
      <div 
        onClick={() => setIsOpen(true)}
        className={`group cursor-pointer relative transition-all hover:scale-110 active:scale-95 ${config.widgetStyle === 'fixed' && !floatingMode ? 'hidden' : 'block'}`}
      >
          {config.sessionPersistenceEnabled && (
            <div className={`absolute ${config.position.includes('top') ? 'top-20' : '-top-12'} right-0 whitespace-nowrap bg-white text-gray-900 px-3 py-1.5 rounded-xl shadow-xl border border-gray-100 text-[10px] font-black uppercase tracking-widest animate-bounce opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none`}>
              {config.welcomeBackMessage}
            </div>
          )}

          <span className="absolute -top-1 -right-1 flex h-4 w-4 z-10">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-4 w-4 bg-red-500 text-[10px] text-white font-bold items-center justify-center">1</span>
          </span>

          <div 
            className="w-16 h-16 rounded-full overflow-hidden border-4 shadow-2xl flex items-center justify-center bg-gray-200"
            style={{ borderColor: config.themeColor }}
          >
              {config.avatarUrl && config.avatarUrl.trim() !== '' ? (
                  <img src={config.avatarUrl} alt="Avatar" className="w-full h-full object-cover" />
              ) : (
                  <MessageSquare size={24} className="text-gray-500" />
              )}
          </div>
      </div>
  );

  const GhlFormPlaceholder = ({ compact = false, onBack }: { compact?: boolean, onBack?: () => void }) => (
      <div className={`w-full ${compact ? 'py-8 px-6' : 'h-full p-8'} bg-gray-50 border-2 border-dashed border-gray-200 rounded-[2rem] flex flex-col items-center justify-center text-center animate-in fade-in zoom-in-95 duration-500 relative z-20`}>
          {onBack && (
              <button 
                onClick={(e) => { e.stopPropagation(); onBack(); }}
                className="absolute top-5 left-5 flex items-center px-4 py-2 bg-white rounded-full shadow-lg border border-gray-100 text-[10px] font-black text-gray-900 hover:text-indigo-600 hover:border-indigo-100 transition-all active:scale-95 group"
              >
                  <ArrowLeft size={12} className="mr-2 group-hover:-translate-x-1 transition-transform" /> BACK TO VIDEO
              </button>
          )}
          
          <div className="w-16 h-16 bg-white rounded-3xl flex items-center justify-center mb-5 text-indigo-600 shadow-2xl shadow-indigo-100/50 border border-indigo-50 transform rotate-3">
              <Send size={28} />
          </div>
          
          <h4 className="text-base font-black text-gray-900 uppercase tracking-tighter mb-2">
            Interactive Form
          </h4>
          
          <p className="text-[11px] text-gray-500 max-w-[220px] font-medium leading-relaxed mb-8">
             {config.ghlInputMethod === 'code' 
                ? 'Your GoHighLevel custom embed code is currently active in this widget.' 
                : 'Form: ' + (config.ghlFormIdOrUrl || 'Ready for data input')}
          </p>

          <div className="w-full space-y-4">
              <div className="h-10 bg-white rounded-xl border border-gray-100 w-full shadow-inner"></div>
              <div className="h-10 bg-white rounded-xl border border-gray-100 w-full shadow-inner"></div>
              <button className="w-full py-4 bg-indigo-600 text-white text-[11px] font-black uppercase tracking-[0.2em] rounded-2xl shadow-xl shadow-indigo-100 transition-transform active:scale-[0.98] mt-2">
                  Send Information
              </button>
          </div>
      </div>
  );

  const ExpandedWidget = () => (
    <div 
        className={`bg-white rounded-[3rem] shadow-[0_50px_100px_-20px_rgba(0,0,0,0.3)] overflow-hidden flex flex-col transition-all duration-700 ease-[cubic-bezier(0.16,1,0.3,1)] relative border border-gray-100 ${config.widgetStyle === 'fixed' && !floatingMode ? 'w-full' : ''}`}
        style={{ 
            width: `${config.videoWidth}px`,
            maxHeight: config.widgetStyle === 'fixed' && !floatingMode ? 'none' : '85vh',
        }}
    >
        {(config.widgetStyle === 'floating' || floatingMode) && (
            <button 
                onClick={(e) => { e.stopPropagation(); setIsOpen(false); }}
                className="absolute top-6 right-6 z-[70] bg-black/30 hover:bg-black/50 text-white rounded-full p-2.5 backdrop-blur-xl transition-all active:scale-90 border border-white/10"
            >
                <X size={22} />
            </button>
        )}

        <div 
            className="relative w-full bg-[#000] shrink-0 overflow-hidden"
            style={{ aspectRatio: '9/16' }}
            onClick={togglePlay}
        >
             {config.ghlEnabled && config.ghlDisplayMode === 'replace-video' && showForm ? (
                 <GhlFormPlaceholder onBack={() => setShowForm(false)} />
             ) : (
                 <div key={config.videoUrl} className="w-full h-full relative">
                    {videoError ? (
                        <div className="w-full h-full flex flex-col items-center justify-center bg-gray-950 text-gray-400 p-12 text-center">
                            <AlertCircle size={48} className="mb-6 text-red-500/50" />
                            <h5 className="text-base font-black text-white mb-3 uppercase tracking-widest">Video Error</h5>
                            <p className="text-[11px] text-gray-500 leading-relaxed font-medium">Please verify your video source URL.</p>
                        </div>
                    ) : youtubeId ? (
                        <iframe
                            className="w-full h-full border-none"
                            src={`https://www.youtube.com/embed/${youtubeId}?autoplay=1&mute=1&controls=1&loop=1&playlist=${youtubeId}&modestbranding=1&rel=0&enablejsapi=1`}
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                            allowFullScreen
                        ></iframe>
                    ) : (
                        <>
                          <video 
                              ref={videoRef}
                              src={config.videoUrl}
                              poster={config.showThumbnail ? config.videoThumbnailUrl : undefined}
                              className="w-full h-full object-cover transition-transform duration-1000"
                              loop
                              muted={isMuted}
                              autoPlay={config.autoplayMuted && isOpen}
                              playsInline
                              onError={() => setVideoError(true)}
                          />
                          {!isPlaying && !videoError && (
                              <div className="absolute inset-0 flex items-center justify-center bg-black/20 hover:bg-black/30 transition-all backdrop-blur-[2px] z-10">
                                  <div className="w-24 h-24 rounded-full bg-white/10 backdrop-blur-2xl border-2 border-white/20 flex items-center justify-center pl-2 shadow-2xl">
                                      <Play fill="white" className="text-white w-10 h-10" />
                                  </div>
                              </div>
                          )}
                          {isPlaying && isMuted && (
                             <button 
                               onClick={toggleMute}
                               className="absolute bottom-6 left-6 z-20 flex items-center space-x-2 bg-black/50 backdrop-blur-md text-white px-4 py-2 rounded-full border border-white/20 animate-in fade-in slide-in-from-bottom-2"
                             >
                               <VolumeX size={16} />
                               <span className="text-[10px] font-black uppercase tracking-widest">Unmute</span>
                             </button>
                          )}
                        </>
                    )}
                 </div>
             )}
        </div>

        <div className="p-8 bg-white relative">
             {config.ghlEnabled && config.ghlDisplayMode === 'slide-up' && showForm && (
                 <div className="absolute inset-x-0 bottom-0 bg-white z-[80] rounded-t-[3rem] shadow-[0_-30px_80px_rgba(0,0,0,0.25)] border-t border-gray-50 transition-all animate-in slide-in-from-bottom duration-700 ease-[cubic-bezier(0.16,1,0.3,1)] flex flex-col">
                     <div className="flex justify-center pt-4 pb-1">
                         <div className="w-16 h-1.5 bg-gray-200 rounded-full"></div>
                     </div>
                     <div className="flex justify-between items-center px-8 py-5 border-b border-gray-50">
                         <span className="text-[11px] font-black uppercase tracking-[0.25em] text-indigo-600">Active Form</span>
                         <button 
                            onClick={() => setShowForm(false)} 
                            className="bg-gray-100 text-gray-500 hover:text-gray-950 p-2.5 rounded-full transition-all active:scale-90"
                         >
                             <ChevronDown size={20}/>
                         </button>
                     </div>
                     <div className="p-2 overflow-y-auto max-h-[450px]">
                        <GhlFormPlaceholder compact />
                     </div>
                 </div>
             )}

            <div className="space-y-4 relative z-10">
                {config.buttons.map((btn, idx) => (
                    <a 
                        key={btn.id}
                        href={btn.link}
                        target={btn.openInNewTab ? "_blank" : "_self"}
                        onClick={(e) => {
                             if (config.ghlEnabled && idx === 0) {
                                e.preventDefault();
                                setShowForm(!showForm);
                             }
                        }}
                        className="block w-full text-center py-5 px-8 rounded-[1.25rem] text-[12px] font-black uppercase tracking-[0.2em] transition-all active:scale-[0.96] shadow-xl shadow-gray-100 hover:shadow-indigo-200/40 hover:-translate-y-0.5"
                        style={{ 
                            backgroundColor: btn.backgroundColor, 
                            color: btn.textColor 
                        }}
                    >
                        {btn.label}
                    </a>
                ))}
            </div>

            {config.ghlEnabled && config.ghlDisplayMode === 'under-video' && (
                 <div className="mt-10 pt-10 border-t border-gray-100">
                     <GhlFormPlaceholder compact />
                 </div>
            )}

            {config.gdprEnabled && (
                <p className="mt-8 text-[10px] text-gray-400 text-center font-black uppercase tracking-[0.1em] opacity-50 px-8">
                    {config.gdprText}
                </p>
            )}
        </div>
    </div>
  );

  if (floatingMode) {
      const floatingPosClass = (() => {
          switch (config.position) {
              case 'bottom-right': return 'bottom-8 right-8';
              case 'bottom-left': return 'bottom-8 left-8';
              case 'top-right': return 'top-8 right-8';
              case 'top-left': return 'top-8 left-8';
              default: return 'bottom-8 right-8';
          }
      })();
      
      return (
        <div className={`fixed z-[99999] ${floatingPosClass} flex flex-col ${config.position.includes('left') ? 'items-start' : 'items-end'} pointer-events-none`}>
             <div className="pointer-events-auto">
                {isOpen ? (
                    <ExpandedWidget />
                ) : (
                    config.showAvatarToggle && <AvatarBubble />
                )}
             </div>
        </div>
      );
  }

  return (
    <div className="relative w-full h-full min-h-[750px] bg-[#050505] overflow-hidden flex items-center justify-center text-gray-300">
        <div className="absolute inset-0 opacity-[0.06] pointer-events-none" style={{ backgroundImage: 'radial-gradient(#fff 2px, transparent 2px)', backgroundSize: '50px 50px' }}></div>
        
        <div className={`${getPositionClasses()} z-50 flex flex-col ${config.position.includes('left') ? 'items-start' : 'items-end'} w-full`}>
            {isOpen || config.widgetStyle === 'fixed' ? (
                <ExpandedWidget />
            ) : (
                config.showAvatarToggle && <AvatarBubble />
            )}
        </div>

        <div className="absolute bottom-12 left-12 flex items-center space-x-4 bg-white/5 border border-white/10 px-8 py-4 rounded-[1.5rem] backdrop-blur-3xl pointer-events-none shadow-2xl">
            <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse shadow-[0_0_15px_rgba(34,197,94,1)]"></div>
            <span className="text-[12px] font-black uppercase tracking-[0.3em] text-gray-400">Builder Preview</span>
        </div>
    </div>
  );
};

export default PreviewPanel;
