# VidFlow Deployment Guide

## Quick Deploy Options

### Option 1: Vercel (Fastest - Recommended)

1. **Fork this repo** to your GitHub account
2. **Go to Vercel** → New Project
3. **Import** your forked repo
4. **Deploy** (zero config needed!)
5. **Copy your deployment URL**

Done! Your VidFlow builder is live.

### Option 2: Netlify

1. **Fork this repo**
2. **Go to Netlify** → New Site from Git
3. **Connect** your repo
4. Build settings:
   - Build command: `npm run build`
   - Publish directory: `dist`
5. **Deploy**

### Option 3: Self-Hosted

```bash
# Build the project
npm run build

# Upload /dist folder to your hosting
# Point your domain to /dist/index.html
```

---

## Deploying Widgets to GoHighLevel

Once you've built a widget, here's how to get it into GHL:

### Method A: GHL Media Library (Recommended)

**Best for:** Agencies managing multiple clients

1. **Generate your widget code** in VidFlow
2. **Save the JavaScript** to a file (e.g., `widget.js`)
3. **Upload to GHL Media Library:**
   - Go to Sites → Media Library
   - Upload `widget.js`
   - Copy the public URL
4. **Add to funnel:**
   - Funnel → Settings → Tracking Code
   - Paste in Header section:
   ```html
   <script src="YOUR_MEDIA_LIBRARY_URL"></script>
   ```
5. **Publish** your funnel

### Method B: Direct Embed

**Best for:** Quick testing or single-use widgets

1. **Copy the generated code** from VidFlow
2. **Go to your funnel page** in GHL
3. **Add Custom Code element:**
   - Drag "Custom Code" element onto page
   - Paste your widget code
   - Choose "Execute in Body"
4. **Publish**

### Method C: Global Site Script

**Best for:** Widget on every page of a site

1. **Generate widget code**
2. **Go to Site Settings** in GHL
3. **Add to Footer Code:**
   - Settings → Footer Scripts
   - Paste widget code
4. **Save** - Widget now appears sitewide

---

## Environment Variables

VidFlow doesn't require env vars for basic usage. But if you're customizing:

```bash
# .env.local (optional)
VITE_DEFAULT_VIDEO_URL=https://your-video.mp4
VITE_DEFAULT_AVATAR=https://your-avatar.jpg
VITE_BRAND_NAME=Your Agency Name
```

---

## Custom Domain Setup

### Vercel
1. Vercel Dashboard → Your Project
2. Settings → Domains
3. Add your domain
4. Update DNS records as shown

### Netlify
1. Netlify Dashboard → Domain Settings
2. Add custom domain
3. Follow DNS configuration

---

## Performance Optimization

### For Maximum Speed:

1. **Enable Compression** (automatic on Vercel/Netlify)
2. **Use CDN** for video files (not YouTube)
3. **Optimize images** - compress avatars/thumbnails
4. **Lazy load** - Widget script loads async by default

### PageSpeed Tips:

- Host videos externally (YouTube or CDN)
- Use WebP/AVIF for thumbnails
- Enable HTTP/2 on your hosting
- Minimize custom fonts

---

## Monitoring & Analytics

### Track Widget Performance:

**Option 1: Google Tag Manager**
```javascript
// Add to widget initialization
VidFlow.on('opened', () => {
  gtag('event', 'widget_opened', {
    'event_category': 'engagement'
  });
});
```

**Option 2: GHL Webhooks**
```javascript
// Fire to GHL workflow
fetch('YOUR_GHL_WEBHOOK_URL', {
  method: 'POST',
  body: JSON.stringify({
    event: 'widget_cta_clicked',
    timestamp: Date.now()
  })
});
```

---

## Troubleshooting

### Widget not appearing?

1. Check browser console for errors
2. Verify script URL is correct
3. Check ad blockers aren't blocking it
4. Ensure page has fully loaded

### Video not playing?

1. **YouTube:** Check video is public
2. **Direct MP4:** Verify CORS headers allow embedding
3. **GHL Media:** Ensure file is public
4. Test in incognito mode (removes extensions)

### Form not submitting?

1. Verify GHL form ID is correct
2. Check form is not archived in GHL
3. Test with simple text input first
4. Check browser console for API errors

---

## White-Label Customization

Want to remove all VidFlow branding?

1. **Update metadata.json:**
```json
{
  "name": "Your Widget Builder",
  "description": "Your description"
}
```

2. **Update App.tsx:**
   - Replace "VidFlow" with your brand
   - Update footer links
   - Change logo/icon

3. **Rebuild:**
```bash
npm run build
```

---

## Security Best Practices

1. **Never expose API keys** in widget code
2. **Validate form inputs** server-side
3. **Use HTTPS** for all video URLs
4. **Sanitize user inputs** if allowing custom HTML
5. **Keep dependencies updated:** `npm audit`

---

## Support

- **Documentation:** This repo's README
- **Issues:** GitHub Issues
- **GHL Community:** Share in Facebook groups
- **Author:** [Arbor Advantage](https://arboradvantage.com)

---

**Built with 🌲 by operators for operators**
