# VidFlow - Interactive Video Widget Builder for GoHighLevel

> Transform your static funnels into high-converting experiences with interactive video widgets. Built specifically for GoHighLevel agencies.

![VidFlow Demo](https://img.shields.io/badge/Status-Production%20Ready-success?style=for-the-badge)
![License](https://img.shields.io/badge/License-MIT-blue?style=for-the-badge)

## 🚀 Live Demo

**[Try VidFlow →](https://your-demo-url.com)** *(Deploy to Vercel/Netlify and add link)*

The demo includes a live widget in the bottom-right corner - **that's the product in action!** Click the pulsing bubble to see it expand.

---

## 🎯 What is VidFlow?

VidFlow is a professional video widget builder that lets GoHighLevel agencies create custom video bubbles that:

- ✅ **Autoplay** with muted video to grab attention
- ✅ **Convert** with customizable CTA buttons  
- ✅ **Integrate** seamlessly with GHL forms
- ✅ **Support** both direct video files AND YouTube embeds
- ✅ **Track** engagement with analytics hooks
- ✅ **White-label** ready (zero branding)

### Why VidFlow?

**Built by operators, for operators.** Created by Jonathan at [Arbor Advantage](https://arboradvantage.com), who's run a 7-figure tree service and scaled 200+ service businesses. This isn't theory - it's battle-tested conversion engineering.

---

## 🎥 Supported Video Sources

| Source | Support | Notes |
|--------|---------|-------|
| **YouTube** | ✅ Full | Embeds with autoplay, loop, controls |
| **Direct MP4** | ✅ Full | Self-hosted or CDN (Archive.org, etc) |
| **Vimeo** | 🔄 Planned | Coming soon |
| **GHL Media Library** | ✅ Full | Upload MP4, grab public URL |

### YouTube URL Formats Supported

```
✅ https://www.youtube.com/watch?v=dQw4w9WgXcQ
✅ https://www.youtube.com/watch?v=dQw4w9WgXcQ&t=1s
✅ https://youtu.be/dQw4w9WgXcQ
✅ https://www.youtube.com/embed/dQw4w9WgXcQ
✅ https://www.youtube.com/shorts/dQw4w9WgXcQ
```

---

## ⚡ Quick Start

### Prerequisites

- Node.js 18+ or Bun
- Modern browser (Chrome, Firefox, Safari, Edge)

### Installation

```bash
# Clone the repo
git clone https://github.com/yourusername/vidflow.git
cd vidflow

# Install dependencies
npm install
# or
bun install

# Start dev server
npm run dev
# or
bun run dev
```

Open `http://localhost:5173` to see VidFlow in action.

---

## 🏗️ Project Structure

```
vidflow/
├── components/
│   ├── ConfigPanel.tsx      # Left sidebar controls
│   ├── PreviewPanel.tsx     # Widget preview & rendering
│   └── CodeGenerator.tsx    # Export code generator
├── App.tsx                  # Main landing page + builder
├── types.ts                 # TypeScript interfaces
├── index.html               # Entry point
└── README.md                # You are here
```

---

## 🎨 Features

### Core Widget Features

- **Floating or Fixed** - Corner bubble or inline embed
- **Smart Positioning** - All 4 corners supported
- **Entrance Animations** - Slide-up, fade-in, bounce
- **Exit Intent Trigger** - Capture abandoning visitors
- **Session Persistence** - Don't show widget to repeat visitors
- **Autoplay Muted** - Complies with browser policies
- **One-Click Unmute** - Clear CTA to enable sound
- **Custom Thumbnails** - Show poster before video loads
- **GDPR Ready** - Optional consent text

### GoHighLevel Integration

- **Native Form Embed** - Paste GHL form code or ID
- **3 Display Modes:**
  - Under Video (inline)
  - Slide-up (overlay)
  - Replace Video (full takeover)
- **Success Actions:**
  - Thank you message
  - Close widget
  - Redirect to URL
- **Webhook Ready** - Fire events to GHL workflows

### Customization

- **Theme Color** - Match your brand
- **Custom Buttons** - Up to 3 CTAs with custom colors
- **Avatar Bubble** - Use any image for collapsed state
- **Video Width** - 280px - 500px responsive scaling
- **White Label** - Zero VidFlow branding in output

---

## 📝 How to Use

### 1. Configure Your Widget

Use the **Customizer** panel on the left:

1. **Paste your video URL** (YouTube or direct MP4)
2. **Set position** (bottom-right, etc)
3. **Add CTA buttons** with custom text/colors
4. **Optional:** Enable GHL form integration

### 2. Preview in Real-Time

The **Live Preview** shows exactly how your widget will look. The demo widget in the bottom-right corner of the page is also fully functional.

### 3. Generate & Deploy

Click **"Copy Widget Code"** to get:

```html
<!-- Paste this before </body> tag -->
<script src="vidflow-widget.js"></script>
<script>
  VidFlow.init({
    videoUrl: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
    position: 'bottom-right',
    buttons: [
      { label: 'Get Started', link: 'https://your-site.com' }
    ]
  });
</script>
```

### 4. Upload to GoHighLevel

**Method A: GHL Media Library**
1. Export the JavaScript file
2. Upload to GHL Media Library
3. Copy the public URL
4. Add to funnel Tracking Code (Header)

**Method B: Direct Embed**
1. Copy the generated code
2. Paste into funnel Custom Code section
3. Publish

---

## 🔧 Configuration Options

### Basic Config

```typescript
interface WidgetConfig {
  // Video
  videoUrl: string;                    // YouTube or MP4 URL
  videoThumbnailUrl?: string;          // Optional poster image
  videoWidth: number;                  // 280-500px
  
  // Positioning
  widgetStyle: 'floating' | 'fixed';   // Corner bubble or inline
  position: 'bottom-right' | 'bottom-left' | 'top-right' | 'top-left';
  
  // Behavior
  autoplayMuted: boolean;              // Start muted (recommended)
  displayDelay: number;                // Seconds before showing
  exitPopEnabled: boolean;             // Trigger on exit intent
  sessionPersistenceEnabled: boolean;  // Remember dismissed state
  
  // Buttons
  buttons: Array<{
    label: string;
    link: string;
    backgroundColor: string;
    textColor: string;
    openInNewTab: boolean;
  }>;
}
```

### GHL Integration Config

```typescript
interface GHLConfig {
  ghlEnabled: boolean;
  ghlInputMethod: 'code' | 'id_url';
  ghlFormIdOrUrl: string;
  ghlDisplayMode: 'under-video' | 'slide-up' | 'replace-video';
  ghlSuccessAction: 'message' | 'close' | 'redirect';
}
```

---

## 🎬 Advanced Usage

### YouTube Embed Parameters

VidFlow automatically configures YouTube embeds with:
- `autoplay=1` - Start immediately
- `mute=1` - Respect browser policies
- `loop=1` - Repeat video
- `controls=1` - Show playback controls
- `modestbranding=1` - Minimal YouTube branding
- `rel=0` - Don't show related videos

### Analytics Hooks

VidFlow fires custom events you can track:

```javascript
// Listen for widget events
window.addEventListener('vidflow:opened', (e) => {
  console.log('Widget opened', e.detail);
  // Fire to GHL webhook
});

window.addEventListener('vidflow:cta_clicked', (e) => {
  console.log('CTA clicked', e.detail);
  // Track conversion
});
```

### Mobile Optimization

Widgets automatically scale down on mobile:
- 320px max width on phones
- Fullscreen takeover option available
- Touch-friendly tap targets
- Swipe-to-dismiss gesture

---

## 🚢 Deployment

### Vercel (Recommended)

[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new/clone?repository-url=https://github.com/yourusername/vidflow)

```bash
npm run build
vercel --prod
```

### Netlify

```bash
npm run build
netlify deploy --prod --dir=dist
```

### Self-Hosted

```bash
npm run build
# Upload /dist folder to your server
```

---

## 🤝 Contributing

Built by [Arbor Advantage](https://arboradvantage.com) for the GoHighLevel community.

Want to contribute? 
1. Fork the repo
2. Create a feature branch
3. Submit a PR with clear description

---

## 📄 License

MIT License - Free for commercial use.

Built with ❤️ for GHL agencies by operators who've been in the trenches.

---

## 🔗 Resources

- **Author:** [Jonathan @ Arbor Advantage](https://arboradvantage.com)
- **Support:** Open an issue on GitHub
- **GHL Community:** Share your widgets!

---

## 🎁 Easter Egg

The default video is Rick Astley's "Never Gonna Give You Up" - because we're **never gonna give your leads up** 😉

Try it: The live demo widget in the bottom-right corner uses this by default. Click it!

---

**Made with 🌲 by Arbor Advantage** | Operational credibility meets direct response marketing.
