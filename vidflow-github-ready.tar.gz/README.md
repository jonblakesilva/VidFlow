# VidFlow - Interactive Video Widget Builder

![VidFlow Demo](https://img.shields.io/badge/Status-Production%20Ready-green)
![License](https://img.shields.io/badge/License-MIT-blue)
![Framework](https://img.shields.io/badge/Framework-React%2019-61dafb)

> Create engaging floating video widgets for your GoHighLevel sites in seconds. No coding required.

[Live Demo](https://your-vercel-url.vercel.app) • [Documentation](#documentation) • [Quick Start](#quick-start)

---

## 🎯 What is VidFlow?

VidFlow is a **no-code builder** for creating interactive video widgets that capture leads on your website. Perfect for tree service businesses, home service companies, and any business using GoHighLevel.

### Key Features

- 🎥 **YouTube & MP4 Support** - Host videos anywhere
- 🎨 **Visual Builder** - No coding required
- 📱 **Mobile Responsive** - Works on all devices
- 🔗 **GHL Integration** - Native form embedding
- ⚡ **One-Click Deploy** - Generate embed code instantly
- 🎨 **Fully Customizable** - Colors, buttons, positioning

---

## 🚀 Quick Start

### Option 1: Use the Hosted Version

1. Visit the [live builder](https://your-vercel-url.vercel.app)
2. Configure your widget settings
3. Download the generated .js file
4. Upload to GoHighLevel Media Library
5. Add embed code to your page

### Option 2: Deploy Your Own

[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new/clone?repository-url=https://github.com/yourusername/vidflow-widget-builder)

### Option 3: Run Locally

```bash
# Clone the repository
git clone https://github.com/yourusername/vidflow-widget-builder.git
cd vidflow-widget-builder

# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build
```

---

## 📦 Tech Stack

- **Framework:** React 19 + TypeScript
- **Styling:** Tailwind CSS
- **Icons:** Lucide React
- **Build Tool:** Vite
- **Deployment:** Vercel

---

## 🎬 Use Cases

- Welcome videos for tree service websites
- Lead capture for home service businesses
- Product demonstrations
- Customer testimonials showcase
- Emergency service promotions
- Seasonal marketing campaigns

---

## 🌐 Deployment to Vercel

1. Push your code to GitHub
2. Import project in Vercel
3. Deploy automatically
4. Get your production URL

### iframe Embedding in GoHighLevel

```html
<iframe 
  src="https://your-vercel-url.vercel.app" 
  width="100%" 
  height="100vh" 
  frameborder="0"
  allow="autoplay; fullscreen"
  style="border: none;"
></iframe>
```

---

## 📝 License

MIT License - Free for commercial use

---

**Made with ❤️ for the tree service industry**
