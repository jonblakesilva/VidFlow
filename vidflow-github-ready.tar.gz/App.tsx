
import React, { useState } from 'react';
import { WidgetConfig, INITIAL_CONFIG } from './types';
import ConfigPanel from './components/ConfigPanel';
import PreviewPanel from './components/PreviewPanel';
import CodeGenerator from './components/CodeGenerator';
import { PlayCircle, Zap, Code, ShieldCheck, ChevronRight } from 'lucide-react';

const App: React.FC = () => {
  const [config, setConfig] = useState<WidgetConfig>(INITIAL_CONFIG);

  const scrollToBuilder = () => {
    const element = document.getElementById('builder-demo');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen font-sans text-gray-900 bg-white">
      
      {/* Navbar */}
      <nav className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center transform rotate-3">
                <PlayCircle className="text-white w-5 h-5" />
              </div>
              <span className="text-xl font-bold tracking-tight text-gray-900">VidFlow</span>
            </div>
            <div className="hidden md:flex items-center space-x-8 text-sm font-medium text-gray-600">
              <a href="#features" className="hover:text-indigo-600 transition-colors">Features</a>
              <a href="#how-it-works" className="hover:text-indigo-600 transition-colors">How it Works</a>
              <a href="#faq" className="hover:text-indigo-600 transition-colors">Installation</a>
            </div>
            <button 
              onClick={scrollToBuilder}
              className="bg-gray-900 text-white px-5 py-2 rounded-full text-sm font-medium hover:bg-gray-800 transition-all shadow-lg hover:shadow-xl transform hover:-translate-y-0.5"
            >
              Build Widget
            </button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative pt-20 pb-32 overflow-hidden">
        <div className="absolute inset-0 -z-10 bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-indigo-100/50 via-white to-white"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
          <div className="inline-flex items-center space-x-2 bg-indigo-50 border border-indigo-100 rounded-full px-3 py-1 mb-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
            <span className="flex h-2 w-2 rounded-full bg-indigo-600"></span>
            <span className="text-xs font-semibold text-indigo-700 tracking-wide uppercase">New: GHL Forms Integration</span>
          </div>
          <h1 className="text-5xl md:text-7xl font-extrabold tracking-tight text-gray-900 mb-6 leading-tight animate-in fade-in slide-in-from-bottom-6 duration-700 delay-100">
            Turn Visitors into Leads with <br />
            <span className="gradient-text bg-gradient-to-r from-indigo-600 to-purple-600">Interactive Video Bubbles</span>
          </h1>
          <p className="max-w-2xl mx-auto text-xl text-gray-500 mb-10 animate-in fade-in slide-in-from-bottom-6 duration-700 delay-200">
            Create personal, floating video widgets for your HighLevel sites in seconds. Engage visitors, book meetings, and capture leads without writing a single line of code.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 animate-in fade-in slide-in-from-bottom-6 duration-700 delay-300">
            <button 
              onClick={scrollToBuilder}
              className="w-full sm:w-auto px-8 py-4 bg-indigo-600 text-white rounded-full font-semibold text-lg hover:bg-indigo-700 transition-all shadow-xl hover:shadow-indigo-200 flex items-center justify-center"
            >
              Start Building Free <ChevronRight className="ml-2 w-5 h-5" />
            </button>
            <a href="#features" className="w-full sm:w-auto px-8 py-4 bg-white text-gray-700 border border-gray-200 rounded-full font-semibold text-lg hover:bg-gray-50 transition-all flex items-center justify-center">
              Learn More
            </a>
          </div>
          
          <div className="mt-12 flex items-center justify-center space-x-8 text-gray-400 grayscale opacity-70 animate-in fade-in zoom-in duration-1000 delay-500">
             <span className="text-sm font-bold tracking-widest">AGENCY<span className="font-light">FLOW</span></span>
             <span className="text-sm font-bold tracking-widest">MARKET<span className="font-light">PRO</span></span>
             <span className="text-sm font-bold tracking-widest">FUNNEL<span className="font-light">HACK</span></span>
             <span className="text-sm font-bold tracking-widest">LEAD<span className="font-light">GEN</span></span>
          </div>
        </div>
      </section>

      {/* Features Grid */}
      <section id="features" className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Everything you need to convert</h2>
            <p className="text-gray-500 max-w-2xl mx-auto">VidFlow combines the human touch of video with the power of automation.</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            <div className="p-8 rounded-2xl bg-gray-50 border border-gray-100 hover:shadow-lg transition-shadow">
              <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center text-blue-600 mb-6">
                <Zap className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">Instant Engagement</h3>
              <p className="text-gray-600">Grab attention immediately with a floating video bubble that welcomes visitors. It's like having a receptionist on your site 24/7.</p>
            </div>
            <div className="p-8 rounded-2xl bg-gray-50 border border-gray-100 hover:shadow-lg transition-shadow">
              <div className="w-12 h-12 bg-indigo-100 rounded-xl flex items-center justify-center text-indigo-600 mb-6">
                <ShieldCheck className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">Native GHL Integration</h3>
              <p className="text-gray-600">Embed your GoHighLevel forms directly inside the video widget. Capture leads and trigger workflows seamlessly.</p>
            </div>
            <div className="p-8 rounded-2xl bg-gray-50 border border-gray-100 hover:shadow-lg transition-shadow">
              <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center text-purple-600 mb-6">
                <Code className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">No Coding Required</h3>
              <p className="text-gray-600">Customize everything with our visual builder. When you're done, just copy one line of code to your website.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Interactive Builder Demo Section */}
      <section id="builder-demo" className="py-20 bg-gray-900 text-white relative overflow-hidden">
        {/* Decorative blobs */}
        <div className="absolute top-0 left-0 w-full h-full overflow-hidden z-0">
            <div className="absolute top-[-10%] left-[-10%] w-[50%] h-[50%] bg-indigo-600/30 rounded-full blur-[100px]"></div>
            <div className="absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] bg-purple-600/30 rounded-full blur-[100px]"></div>
        </div>

        <div className="max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Live Interactive Demo</h2>
            <p className="text-gray-400 max-w-2xl mx-auto">Try the builder right here. Customize your widget and see the preview update instantly.</p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 h-auto lg:h-[800px] bg-gray-950/50 backdrop-blur-sm rounded-3xl p-4 lg:p-6 border border-white/10 shadow-2xl">
             {/* Left: Controls */}
             <div className="lg:col-span-4 bg-white rounded-2xl p-6 text-gray-900 overflow-y-auto custom-scrollbar shadow-inner">
                <div className="mb-6 pb-4 border-b border-gray-100">
                    <h3 className="font-bold text-xl text-gray-900">Widget Configuration</h3>
                    <p className="text-xs text-gray-500">Edit settings below to update the preview</p>
                </div>
                <ConfigPanel config={config} onChange={setConfig} />
             </div>

             {/* Right: Preview & Code */}
             <div className="lg:col-span-8 flex flex-col space-y-6">
                 {/* Preview */}
                 <div className="flex-grow bg-gray-800 rounded-2xl overflow-hidden border border-gray-700 shadow-2xl relative">
                    <div className="absolute top-4 left-4 z-10 bg-black/50 backdrop-blur px-3 py-1.5 rounded-full text-xs font-semibold text-white border border-white/10 flex items-center">
                        <div className="w-2 h-2 rounded-full bg-green-500 mr-2 animate-pulse"></div>
                        Live Preview
                    </div>
                    <PreviewPanel config={config} />
                 </div>
                 
                 {/* Output Code */}
                 <CodeGenerator config={config} />
             </div>
          </div>
        </div>
      </section>

      {/* FAQ / Installation Section */}
      <section id="faq" className="py-24 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">How to install on GoHighLevel</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="bg-gray-50 rounded-2xl p-8 border border-gray-100">
                    <div className="w-8 h-8 bg-indigo-600 text-white rounded-full flex items-center justify-center font-bold mb-4">1</div>
                    <h3 className="text-lg font-bold text-gray-900 mb-2">Generate Script</h3>
                    <p className="text-gray-600 text-sm">
                        Use the builder above to customize your widget. When ready, click <strong>"Download .js File"</strong>. This file contains all your settings and widget logic.
                    </p>
                </div>
                
                <div className="bg-gray-50 rounded-2xl p-8 border border-gray-100">
                     <div className="w-8 h-8 bg-indigo-600 text-white rounded-full flex items-center justify-center font-bold mb-4">2</div>
                    <h3 className="text-lg font-bold text-gray-900 mb-2">Upload to Media Library</h3>
                    <p className="text-gray-600 text-sm">
                        Go to your GHL account &gt; Sites &gt; Media Library. Upload the <code>vidflow.js</code> file you just downloaded. Right click it and select "Get Link".
                    </p>
                </div>

                <div className="bg-gray-50 rounded-2xl p-8 border border-gray-100">
                     <div className="w-8 h-8 bg-indigo-600 text-white rounded-full flex items-center justify-center font-bold mb-4">3</div>
                    <h3 className="text-lg font-bold text-gray-900 mb-2">Add to Funnel</h3>
                    <p className="text-gray-600 text-sm">
                        Go to your Funnel Page Settings &gt; Tracking Code &gt; <strong>Footer Code</strong>. Paste the embed snippet and replace the placeholder URL with your Media Library link.
                    </p>
                </div>

                <div className="bg-gray-50 rounded-2xl p-8 border border-gray-100">
                     <div className="w-8 h-8 bg-indigo-600 text-white rounded-full flex items-center justify-center font-bold mb-4">4</div>
                    <h3 className="text-lg font-bold text-gray-900 mb-2">Publish</h3>
                    <p className="text-gray-600 text-sm">
                        Save and Publish your page. The widget will appear! If you need to update it later, just download a new file and replace it in your Media Library.
                    </p>
                </div>
            </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12 border-t border-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center space-x-2 mb-4 md:mb-0">
                <PlayCircle className="text-indigo-500 w-6 h-6" />
                <span className="text-xl font-bold tracking-tight">VidFlow</span>
            </div>
            <div className="text-gray-400 text-sm">
                &copy; 2025 VidFlow. All rights reserved.
            </div>
        </div>
      </footer>
    </div>
  );
};

export default App;
