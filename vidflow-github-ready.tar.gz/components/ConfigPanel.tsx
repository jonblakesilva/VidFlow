import React from 'react';
import { Plus, Trash2, HelpCircle, AlertCircle } from 'lucide-react';
import { WidgetConfig, WidgetPosition, WidgetStyle, GhlInputMethod, GhlDisplayMode, GhlSuccessAction, OverlayButton } from '../types';

interface ConfigPanelProps {
  config: WidgetConfig;
  onChange: (newConfig: WidgetConfig) => void;
}

const ConfigPanel: React.FC<ConfigPanelProps> = ({ config, onChange }) => {
  
  const handleChange = <K extends keyof WidgetConfig>(key: K, value: WidgetConfig[K]) => {
    onChange({ ...config, [key]: value });
  };

  const handleButtonChange = (id: string, field: keyof OverlayButton, value: any) => {
    const newButtons = config.buttons.map(btn => 
      btn.id === id ? { ...btn, [field]: value } : btn
    );
    handleChange('buttons', newButtons);
  };

  const addButton = () => {
    if (config.buttons.length >= 3) return;
    const newButton: OverlayButton = {
      id: crypto.randomUUID(),
      label: 'New Button',
      link: '#',
      backgroundColor: config.themeColor,
      textColor: '#ffffff',
      openInNewTab: true
    };
    handleChange('buttons', [...config.buttons, newButton]);
  };

  const removeButton = (id: string) => {
    handleChange('buttons', config.buttons.filter(b => b.id !== id));
  };

  return (
    <div className="space-y-8 h-full">
      {/* Video Settings */}
      <section className="space-y-4">
        <h3 className="text-sm font-bold uppercase tracking-wider text-gray-400 mb-4">Video Controls</h3>
        
        <div className="space-y-2">
            <label className="block text-sm font-medium text-gray-700">Video Source URL</label>
            <input
              type="text"
              value={config.videoUrl}
              onChange={(e) => handleChange('videoUrl', e.target.value)}
              className="w-full px-4 py-2 bg-gray-50 border border-gray-200 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 text-sm transition-all"
              placeholder="https://www.youtube.com/embed/dQw4w9WgXcQ or video.mp4"
            />
            <p className="text-xs text-gray-500 flex items-start gap-1">
              <HelpCircle className="w-3 h-3 mt-0.5 shrink-0" />
              <span>Supports YouTube embeds or direct MP4 URLs. For YouTube, use the embed format.</span>
            </p>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <label className="block text-sm font-medium text-gray-700">Video Width (px)</label>
            <input
              type="number"
              value={config.videoWidth}
              onChange={(e) => handleChange('videoWidth', Number(e.target.value))}
              min={200}
              max={500}
              className="w-full px-4 py-2 bg-gray-50 border border-gray-200 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 text-sm transition-all"
            />
            <p className="text-xs text-gray-400">Height is auto (9:16)</p>
          </div>
          <div className="space-y-2">
            <label className="block text-sm font-medium text-gray-700">Theme Color</label>
            <div className="flex items-center space-x-2 bg-gray-50 p-1.5 rounded-lg border border-gray-200">
              <input
                type="color"
                value={config.themeColor}
                onChange={(e) => handleChange('themeColor', e.target.value)}
                className="h-8 w-10 p-0 border-0 rounded overflow-hidden cursor-pointer"
              />
              <span className="text-sm text-gray-500 font-mono flex-grow">{config.themeColor}</span>
            </div>
          </div>
        </div>
      </section>

      {/* Appearance */}
      <section className="space-y-4">
        <h3 className="text-sm font-bold uppercase tracking-wider text-gray-400 mb-4 pt-4 border-t border-gray-100">Appearance</h3>
        
        <div className="space-y-2">
          <label className="block text-sm font-medium text-gray-700">Avatar Image URL</label>
          <input
            type="text"
            value={config.avatarUrl}
            onChange={(e) => handleChange('avatarUrl', e.target.value)}
            className="w-full px-4 py-2 bg-gray-50 border border-gray-200 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 text-sm transition-all"
            placeholder="https://example.com/avatar.jpg"
          />
        </div>

        <div className="flex items-center space-x-2">
          <input
            type="checkbox"
            id="avatarToggle"
            checked={config.showAvatarToggle}
            onChange={(e) => handleChange('showAvatarToggle', e.target.checked)}
            className="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded"
          />
          <label htmlFor="avatarToggle" className="text-sm text-gray-700">Show Avatar Bubble</label>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
                <label className="block text-sm font-medium text-gray-700">Widget Style</label>
                <select
                    value={config.widgetStyle}
                    onChange={(e) => handleChange('widgetStyle', e.target.value as WidgetStyle)}
                    className="w-full px-3 py-2 bg-gray-50 border border-gray-200 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 text-sm"
                >
                    <option value="floating">Floating</option>
                    <option value="fixed">Fixed (Inline)</option>
                </select>
            </div>
            
            <div className="space-y-2">
                <label className="block text-sm font-medium text-gray-700">Position</label>
                <select
                    value={config.position}
                    disabled={config.widgetStyle === 'fixed'}
                    onChange={(e) => handleChange('position', e.target.value as WidgetPosition)}
                    className="w-full px-3 py-2 bg-gray-50 border border-gray-200 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 text-sm disabled:opacity-50 disabled:bg-gray-100"
                >
                    <option value="bottom-right">Bottom Right</option>
                    <option value="bottom-left">Bottom Left</option>
                    <option value="top-right">Top Right</option>
                    <option value="top-left">Top Left</option>
                </select>
            </div>
        </div>
      </section>

      {/* Buttons */}
      <section className="space-y-4">
        <div className="flex justify-between items-center pt-4 border-t border-gray-100">
            <h3 className="text-sm font-bold uppercase tracking-wider text-gray-400">Calls to Action</h3>
            <span className="text-xs text-gray-400 font-medium bg-gray-100 px-2 py-1 rounded-full">{config.buttons.length}/3</span>
        </div>
        
        <div className="space-y-3">
            {config.buttons.map((btn, index) => (
                <div key={btn.id} className="p-3 border border-gray-200 rounded-lg bg-gray-50/50 space-y-3 hover:bg-white hover:shadow-sm transition-all">
                    <div className="flex justify-between items-center">
                        <span className="text-xs font-semibold text-gray-500 uppercase">Button {index + 1}</span>
                        <button onClick={() => removeButton(btn.id)} className="text-gray-400 hover:text-red-500 transition-colors">
                            <Trash2 size={14} />
                        </button>
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                        <input 
                            type="text" 
                            value={btn.label}
                            onChange={(e) => handleButtonChange(btn.id, 'label', e.target.value)}
                            placeholder="Label"
                            className="w-full px-3 py-1.5 border border-gray-200 rounded text-sm bg-white"
                        />
                         <input 
                            type="text" 
                            value={btn.link}
                            onChange={(e) => handleButtonChange(btn.id, 'link', e.target.value)}
                            placeholder="URL"
                            className="w-full px-3 py-1.5 border border-gray-200 rounded text-sm bg-white"
                        />
                    </div>
                </div>
            ))}
            
            {config.buttons.length < 3 && (
                <button
                    onClick={addButton}
                    className="w-full py-3 border-2 border-dashed border-gray-200 rounded-lg text-gray-400 hover:border-indigo-500 hover:text-indigo-500 flex items-center justify-center transition-all hover:bg-indigo-50 font-medium text-sm"
                >
                    <Plus size={16} className="mr-2" /> Add Action Button
                </button>
            )}
        </div>
      </section>

      {/* GoHighLevel Integration */}
      <section className="space-y-4 p-5 bg-gradient-to-br from-indigo-50 to-blue-50 rounded-xl border border-indigo-100/50 shadow-sm">
        <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
                <div className="bg-indigo-600 text-white p-1 rounded">
                    <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/></svg>
                </div>
                <h3 className="text-sm font-bold text-indigo-900">GHL Forms</h3>
            </div>
            <div className="flex items-center">
                 <button 
                    onClick={() => handleChange('ghlEnabled', !config.ghlEnabled)}
                    className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 ${config.ghlEnabled ? 'bg-indigo-600' : 'bg-gray-300'}`}
                 >
                     <span className={`inline-block h-4 w-4 transform rounded-full bg-white transition duration-200 ease-in-out ${config.ghlEnabled ? 'translate-x-6' : 'translate-x-1'}`} />
                 </button>
            </div>
        </div>

        {config.ghlEnabled && (
            <div className="space-y-4 animate-in fade-in slide-in-from-top-2 duration-300 pt-2">
                {/* Input Method */}
                <div className="bg-white/50 p-1 rounded-lg flex text-sm">
                    <button 
                        onClick={() => handleChange('ghlInputMethod', 'code')}
                        className={`flex-1 py-1.5 rounded-md transition-all ${config.ghlInputMethod === 'code' ? 'bg-white shadow text-indigo-700 font-medium' : 'text-gray-500 hover:text-gray-700'}`}
                    >
                        Paste Embed Code
                    </button>
                    <button 
                        onClick={() => handleChange('ghlInputMethod', 'id_url')}
                        className={`flex-1 py-1.5 rounded-md transition-all ${config.ghlInputMethod === 'id_url' ? 'bg-white shadow text-indigo-700 font-medium' : 'text-gray-500 hover:text-gray-700'}`}
                    >
                        Use ID / URL
                    </button>
                </div>

                {/* Code/ID Input */}
                {config.ghlInputMethod === 'code' ? (
                     <div className="space-y-2">
                        <textarea
                            value={config.ghlEmbedCode}
                            onChange={(e) => handleChange('ghlEmbedCode', e.target.value)}
                            rows={3}
                            className={`w-full px-3 py-2 bg-white border rounded-md text-xs font-mono ${!config.ghlEmbedCode ? 'border-red-300 focus:ring-red-500' : 'border-gray-200 focus:ring-indigo-500'}`}
                            placeholder="Paste the full <script> or <iframe> code from HighLevel here..."
                        />
                        {!config.ghlEmbedCode && <p className="text-xs text-red-500 flex items-center"><AlertCircle size={10} className="mr-1"/> Code is required</p>}
                     </div>
                ) : (
                    <div className="space-y-2">
                        <input
                            type="text"
                            value={config.ghlFormIdOrUrl}
                            onChange={(e) => handleChange('ghlFormIdOrUrl', e.target.value)}
                            className={`w-full px-3 py-2 bg-white border rounded-md text-sm ${!config.ghlFormIdOrUrl ? 'border-red-300 focus:ring-red-500' : 'border-gray-200 focus:ring-indigo-500'}`}
                            placeholder="https://api.leadconnectorhq.com/widget/form/..."
                        />
                        {!config.ghlFormIdOrUrl && <p className="text-xs text-red-500 flex items-center"><AlertCircle size={10} className="mr-1"/> Link is required</p>}
                    </div>
                )}

                {/* Display Mode */}
                <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-1">
                        <label className="text-xs font-medium text-gray-500">Display</label>
                        <select
                            value={config.ghlDisplayMode}
                            onChange={(e) => handleChange('ghlDisplayMode', e.target.value as GhlDisplayMode)}
                            className="w-full px-2 py-2 bg-white border border-gray-200 rounded-md text-sm"
                        >
                            <option value="slide-up">Slide-up</option>
                            <option value="under-video">Under Video</option>
                            <option value="replace-video">Replace Video</option>
                        </select>
                    </div>
                    <div className="space-y-1">
                        <label className="text-xs font-medium text-gray-500">On Success</label>
                        <select
                            value={config.ghlSuccessAction}
                            onChange={(e) => handleChange('ghlSuccessAction', e.target.value as GhlSuccessAction)}
                            className="w-full px-2 py-2 bg-white border border-gray-200 rounded-md text-sm"
                        >
                            <option value="message">Message</option>
                            <option value="close">Close</option>
                            <option value="redirect">Redirect</option>
                        </select>
                    </div>
                </div>

                {config.ghlSuccessAction === 'message' && (
                     <input
                        type="text"
                        value={config.ghlThankYouMessage}
                        onChange={(e) => handleChange('ghlThankYouMessage', e.target.value)}
                        className="w-full px-3 py-2 bg-white border border-gray-200 rounded-md text-sm"
                        placeholder="Thank you message..."
                    />
                )}
                 {config.ghlSuccessAction === 'redirect' && (
                     <input
                        type="text"
                        value={config.ghlRedirectUrl}
                        onChange={(e) => handleChange('ghlRedirectUrl', e.target.value)}
                        placeholder="Redirect URL (https://...)"
                        className="w-full px-3 py-2 bg-white border border-gray-200 rounded-md text-sm"
                    />
                )}
            </div>
        )}
      </section>
    </div>
  );
};

export default ConfigPanel;