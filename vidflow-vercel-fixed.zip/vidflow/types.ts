
export type WidgetPosition = 'bottom-right' | 'bottom-left' | 'top-right' | 'top-left';
export type WidgetStyle = 'floating' | 'fixed';
export type GhlInputMethod = 'code' | 'id_url';
export type GhlDisplayMode = 'under-video' | 'slide-up' | 'replace-video';
export type GhlSuccessAction = 'message' | 'close' | 'redirect';
export type EntranceAnimation = 'slide-up' | 'fade-in' | 'bounce' | 'none';

export interface OverlayButton {
  id: string;
  label: string;
  link: string;
  backgroundColor: string;
  textColor: string;
  openInNewTab: boolean;
}

export interface WidgetConfig {
  // Video & General
  videoUrl: string;
  videoThumbnailUrl: string;
  showThumbnail: boolean;
  videoWidth: number;
  themeColor: string;
  avatarUrl: string;
  showAvatarToggle: boolean;
  startExpanded: boolean;
  widgetStyle: WidgetStyle;
  position: WidgetPosition;
  
  // Advanced Settings
  entranceAnimation: EntranceAnimation;
  displayDelay: number; // in seconds
  showCloseButton: boolean;
  gdprEnabled: boolean;
  gdprText: string;

  // Performance Features
  exitPopEnabled: boolean;
  sessionPersistenceEnabled: boolean;
  welcomeBackMessage: string;
  autoplayMuted: boolean;

  // Overlay Buttons
  buttons: OverlayButton[];

  // GoHighLevel Settings
  ghlEnabled: boolean;
  ghlInputMethod: GhlInputMethod;
  ghlEmbedCode: string;
  ghlFormIdOrUrl: string;
  ghlDisplayMode: GhlDisplayMode;
  ghlSuccessAction: GhlSuccessAction;
  ghlRedirectUrl: string;
  ghlThankYouMessage: string;
}

export const INITIAL_CONFIG: WidgetConfig = {
  // Rickroll as default to test YouTube compatibility specifically
  videoUrl: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ', 
  videoThumbnailUrl: 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&w=800&q=80',
  showThumbnail: true,
  videoWidth: 320,
  themeColor: '#6366f1',
  avatarUrl: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?ixlib=rb-1.2.1&auto=format&fit=crop&w=200&q=80',
  showAvatarToggle: true,
  startExpanded: false,
  widgetStyle: 'floating',
  position: 'bottom-right',
  entranceAnimation: 'slide-up',
  displayDelay: 0,
  showCloseButton: true,
  gdprEnabled: false,
  gdprText: 'By clicking, you agree to our terms.',
  exitPopEnabled: true,
  sessionPersistenceEnabled: true,
  welcomeBackMessage: 'Welcome back! 👋',
  autoplayMuted: true,
  buttons: [
    {
      id: 'btn-1',
      label: 'Get Your Free Audit 🎁',
      link: 'https://arboradvantage.com',
      backgroundColor: '#6366f1',
      textColor: '#ffffff',
      openInNewTab: true
    }
  ],
  ghlEnabled: false,
  ghlInputMethod: 'id_url',
  ghlEmbedCode: '',
  ghlFormIdOrUrl: '',
  ghlDisplayMode: 'slide-up',
  ghlSuccessAction: 'message',
  ghlRedirectUrl: '',
  ghlThankYouMessage: 'Thanks! We will be in touch shortly.',
};
