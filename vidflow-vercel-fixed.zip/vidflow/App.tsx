
import React, { useState } from 'react';
import { WidgetConfig, INITIAL_CONFIG } from './types';
import ConfigPanel from './components/ConfigPanel';
import PreviewPanel from './components/PreviewPanel';
import CodeGenerator from './components/CodeGenerator';
import { PlayCircle, Zap, ShieldCheck, ChevronRight, HelpCircle, Mail, Globe, ExternalLink, ArrowUpRight, Monitor, Layers, Send, Award, Users, TrendingUp, CheckCircle } from 'lucide-react';

const App: React.FC = () => {
  const [config, setConfig] = useState<WidgetConfig>(INITIAL_CONFIG);

  const scrollToBuilder = () => {
    document.getElementById('builder-demo')?.scrollIntoView({ behavior: 'smooth' });
  };

  const scrollToHowItWorks = () => {
    document.getElementById('how-it-works')?.scrollIntoView({ behavior: 'smooth' });
  };

  const scrollToFeatures = () => {
    document.getElementById('features')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen font-sans text-gray-900 bg-white selection:bg-indigo-100">
      
      {/* Global Live Demo Widget (Bottom Right) - Mounts outside builder, follows page scroll */}
      <PreviewPanel config={config} floatingMode={true} />

      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-[100] bg-white/80 backdrop-blur-2xl border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-20">
            <div className="flex items-center space-x-4 group cursor-pointer" onClick={() => window.scrollTo({top: 0, behavior: 'smooth'})}>
              <div className="w-12 h-12 bg-indigo-600 rounded-[1.25rem] flex items-center justify-center transform group-hover:rotate-12 transition-all duration-500 shadow-xl shadow-indigo-200">
                <PlayCircle className="text-white w-7 h-7" />
              </div>
              <span className="text-2xl font-black tracking-tighter text-gray-900">VidFlow</span>
            </div>
            <div className="hidden lg:flex items-center space-x-12 text-[11px] font-black text-gray-500 uppercase tracking-[0.2em]">
              <button onClick={scrollToHowItWorks} className="hover:text-indigo-600 transition-colors">How it Works</button>
              <button onClick={scrollToFeatures} className="hover:text-indigo-600 transition-colors">Features</button>
              <a href="#builder-demo" className="hover:text-indigo-600 transition-colors">Builder</a>
            </div>
            <button 
              onClick={scrollToBuilder}
              className="bg-gray-950 text-white px-8 py-4 rounded-2xl text-[11px] font-black uppercase tracking-[0.2em] hover:bg-indigo-600 transition-all shadow-2xl hover:shadow-indigo-200 hover:-translate-y-1 active:scale-95"
            >
              Start Building
            </button>
          </div>
        </div>
      </nav>

      {/* Hero */}
      <section className="relative pt-52 pb-32 overflow-hidden">
        <div className="absolute top-0 right-0 -translate-y-1/2 translate-x-1/2 w-[900px] h-[900px] bg-indigo-50 rounded-full blur-[150px] -z-10"></div>
        <div className="max-w-7xl mx-auto px-4 text-center">
          <div className="inline-flex items-center space-x-3 bg-indigo-50 border border-indigo-100 rounded-full px-6 py-2.5 mb-12">
            <span className="flex h-3 w-3 rounded-full bg-indigo-600 animate-pulse"></span>
            <span className="text-[12px] font-black text-indigo-700 tracking-[0.3em] uppercase">Agency-First Video Infrastructure</span>
          </div>
          <h1 className="text-7xl lg:text-[9rem] font-black tracking-tighter text-gray-950 mb-10 leading-[0.85]">
            Lead Gen is Now <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 via-purple-600 to-indigo-600">Cinematic</span>
          </h1>
          <p className="max-w-4xl mx-auto text-xl lg:text-2xl text-gray-500 mb-16 font-medium leading-relaxed">
            Standard landing pages are dying. VidFlow builds interactive video assets that bridge the gap between human connection and automated CRM results.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-8">
            <button 
              onClick={scrollToBuilder}
              className="w-full sm:w-auto px-12 py-6 bg-gray-950 text-white rounded-[2rem] font-black uppercase tracking-[0.2em] text-[13px] hover:bg-indigo-600 transition-all shadow-3xl hover:shadow-indigo-300/50 flex items-center justify-center group"
            >
              Build My Widget <ChevronRight className="ml-3 group-hover:translate-x-2 transition-transform" />
            </button>
          </div>
        </div>
      </section>

      {/* Authority/Social Proof Section */}
      <section className="py-24 bg-white border-y border-gray-100">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-12 items-center opacity-40 grayscale hover:grayscale-0 transition-all duration-700">
             <div className="flex items-center justify-center font-black text-3xl tracking-tighter uppercase italic">GHL PARTNER</div>
             <div className="flex items-center justify-center font-black text-3xl tracking-tighter uppercase italic">ARBOR ADV.</div>
             <div className="flex items-center justify-center font-black text-3xl tracking-tighter uppercase italic">SCALE FORCE</div>
             <div className="flex items-center justify-center font-black text-3xl tracking-tighter uppercase italic">AGENCY HUB</div>
          </div>
          
          <div className="mt-24 grid grid-cols-1 md:grid-cols-3 gap-12">
            <div className="flex flex-col items-center text-center p-10 bg-indigo-50/50 rounded-[3rem] border border-indigo-100">
                <Users size={32} className="text-indigo-600 mb-6" />
                <h4 className="text-4xl font-black tracking-tighter mb-2">500+</h4>
                <p className="text-gray-500 font-bold uppercase tracking-widest text-[11px]">Active Agency Users</p>
            </div>
            <div className="flex flex-col items-center text-center p-10 bg-indigo-50/50 rounded-[3rem] border border-indigo-100">
                <TrendingUp size={32} className="text-indigo-600 mb-6" />
                <h4 className="text-4xl font-black tracking-tighter mb-2">2.4M</h4>
                <p className="text-gray-500 font-bold uppercase tracking-widest text-[11px]">Leads Generated</p>
            </div>
            <div className="flex flex-col items-center text-center p-10 bg-indigo-50/50 rounded-[3rem] border border-indigo-100">
                <Award size={32} className="text-indigo-600 mb-6" />
                <h4 className="text-4xl font-black tracking-tighter mb-2">#1</h4>
                <p className="text-gray-500 font-bold uppercase tracking-widest text-[11px]">Conversion Tool for GHL</p>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section id="how-it-works" className="py-32 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-20">
            <h2 className="text-5xl font-black tracking-tighter mb-6">Built for High-Ticket Funnels</h2>
            <p className="text-gray-500 font-medium text-lg">Engineered for sub-accounts that demand elite presentation.</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            {[
              { icon: Monitor, title: "1. Upload & Link", desc: "Use your GHL media library to host videos. Paste the link into VidFlow and customize your brand's unique DNA." },
              { icon: Layers, title: "2. Trigger Action", desc: "Convert attention into results. Add CTAs or trigger GoHighLevel forms directly within the video experience." },
              { icon: Send, title: "3. Single Script", desc: "One lightweight script manages the entire experience. Update your widget settings without ever changing the site code." }
            ].map((step, i) => (
              <div key={i} className="bg-white p-10 rounded-[3rem] border border-gray-100 shadow-xl shadow-gray-200/50 relative">
                <div className="w-16 h-16 bg-indigo-600 text-white rounded-2xl flex items-center justify-center mb-8 shadow-lg shadow-indigo-200">
                  <step.icon size={28} />
                </div>
                <h3 className="text-2xl font-black mb-4 tracking-tight">{step.title}</h3>
                <p className="text-gray-500 font-medium leading-relaxed">{step.desc}</p>
                <div className="absolute -top-4 -right-4 w-12 h-12 bg-gray-950 text-white flex items-center justify-center rounded-full font-black italic">0{i+1}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonial Section */}
      <section className="py-32 bg-white overflow-hidden">
        <div className="max-w-7xl mx-auto px-4">
            <div className="bg-gray-950 rounded-[4rem] p-16 lg:p-24 relative overflow-hidden">
                <div className="absolute top-0 right-0 w-1/2 h-full bg-gradient-to-l from-indigo-900/20 to-transparent"></div>
                <div className="relative z-10 flex flex-col lg:flex-row items-center gap-16">
                    <div className="lg:w-1/3">
                        <img 
                            src="https://images.unsplash.com/photo-1621905251918-48416bd8575a?auto=format&fit=crop&w=800&q=80" 
                            className="w-full aspect-square object-cover rounded-[3rem] shadow-2xl shadow-indigo-500/10 grayscale hover:grayscale-0 transition-all duration-700" 
                            alt="HVAC Business Owner"
                        />
                    </div>
                    <div className="lg:w-2/3">
                        <div className="flex space-x-2 mb-8">
                            {[1,2,3,4,5].map(s => <CheckCircle key={s} className="text-indigo-500" size={20} />)}
                        </div>
                        <h3 className="text-white text-3xl lg:text-5xl font-black tracking-tight leading-tight mb-8 italic">
                            "VidFlow changed how we pitch GHL sub-accounts. The level of professionalism this adds to a funnel is unmatched. Our conversion rates for service businesses jumped 40% overnight."
                        </h3>
                        <div>
                            <p className="text-white font-black text-xl uppercase tracking-widest">Sterling Services</p>
                            <p className="text-indigo-400 font-bold tracking-widest uppercase text-[12px] mt-1">HVAC & Mechanical Solutions</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
      </section>

      {/* Additional Niche Proof Section */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4">
           <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="bg-white p-12 rounded-[3rem] shadow-sm border border-gray-100">
                  <div className="flex items-center space-x-4 mb-6">
                      <div className="w-12 h-12 bg-green-50 rounded-2xl flex items-center justify-center text-green-600"><CheckCircle size={24} /></div>
                      <h4 className="text-xl font-black uppercase tracking-tight">Tree Service Success</h4>
                  </div>
                  <p className="text-gray-500 italic font-medium leading-relaxed">"Adding a human face to our emergency tree removal landing page doubled our high-ticket storm lead calls. People trust us before they even pick up the phone."</p>
                  <p className="mt-6 font-black text-sm uppercase tracking-widest text-gray-900">— Operations Manager, Regional Tree Care</p>
              </div>
              <div className="bg-white p-12 rounded-[3rem] shadow-sm border border-gray-100">
                  <div className="flex items-center space-x-4 mb-6">
                      <div className="w-12 h-12 bg-blue-50 rounded-2xl flex items-center justify-center text-blue-600"><CheckCircle size={24} /></div>
                      <h4 className="text-xl font-black uppercase tracking-tight">Contractor Conversion</h4>
                  </div>
                  <p className="text-gray-500 italic font-medium leading-relaxed">"The interactive video form is a game-changer. Our kitchen remodel leads are pre-vetted and highly motivated by the time they hit our CRM."</p>
                  <p className="mt-6 font-black text-sm uppercase tracking-widest text-gray-900">— Lead Designer, Modern Remodeling Co.</p>
              </div>
           </div>
        </div>
      </section>

      {/* Features Grid */}
      <section id="features" className="py-32 border-y border-gray-100 bg-white">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-20">
            {[
              { icon: Globe, title: "Universal Stack", desc: "One script works everywhere. Optimized specifically for the GoHighLevel ecosystem and tracking." },
              { icon: ShieldCheck, title: "White-Label Ready", desc: "No watermarks. No logos. Pure professional performance for your high-ticket client accounts." },
              { icon: Zap, title: "Sub-1s Load Time", desc: "Lightweight engine won't touch your Core Web Vitals. Keep your SEO and paid ads performance high." }
            ].map((f, i) => (
              <div key={i} className="group">
                <div className="w-20 h-20 bg-gray-50 rounded-[2rem] flex items-center justify-center text-gray-950 mb-10 group-hover:bg-indigo-600 group-hover:text-white transition-all duration-500 shadow-sm group-hover:shadow-xl group-hover:shadow-indigo-200">
                  <f.icon size={32} />
                </div>
                <h3 className="text-3xl font-black mb-5 tracking-tight">{f.title}</h3>
                <p className="text-gray-500 font-medium text-lg leading-relaxed">{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Main Builder Experience */}
      <section id="builder-demo" className="py-32 bg-gray-50 overflow-visible relative">
        <div className="max-w-[1500px] mx-auto px-4 lg:px-12">
          <div className="mb-24 text-center">
            <h2 className="text-5xl lg:text-7xl font-black tracking-tighter mb-8">Asset Customizer</h2>
            <p className="text-gray-500 font-medium text-xl max-w-2xl mx-auto leading-relaxed">Control every pixel of your widget's DNA. Preview in real-time in the builder before you ship.</p>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start relative">
            {/* Control Panel (Left) */}
            <div className="lg:col-span-4 bg-white rounded-[3rem] p-12 shadow-2xl shadow-gray-200 border border-gray-100 min-h-[800px]">
              <div className="flex items-center space-x-4 mb-10">
                  <div className="w-10 h-10 bg-indigo-50 text-indigo-600 rounded-xl flex items-center justify-center">
                    <Zap size={20} />
                  </div>
                  <h3 className="text-2xl font-black uppercase tracking-tight text-gray-950">Engine Settings</h3>
              </div>
              <ConfigPanel config={config} onChange={setConfig} />
            </div>

            {/* Sticky Preview (Right) */}
            <div className="lg:col-span-8 space-y-12 lg:sticky lg:top-28">
              <div className="bg-gray-950 rounded-[4rem] overflow-hidden shadow-[0_50px_150px_-30px_rgba(0,0,0,0.5)] border-[15px] border-white aspect-video relative group ring-2 ring-gray-100">
                <PreviewPanel config={config} />
              </div>
              <CodeGenerator config={config} />
            </div>
          </div>
        </div>
      </section>

      {/* Professional Footer */}
      <footer className="bg-gray-950 text-white py-32">
        <div className="max-w-7xl mx-auto px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-24 mb-32">
            <div className="md:col-span-2">
              <div className="flex items-center space-x-5 mb-12">
                <div className="w-16 h-16 bg-indigo-600 rounded-[1.5rem] flex items-center justify-center shadow-3xl shadow-indigo-900/50">
                  <PlayCircle className="text-white w-9 h-9" />
                </div>
                <span className="text-5xl font-black tracking-tighter">VidFlow</span>
              </div>
              <p className="text-gray-400 max-w-md font-medium leading-relaxed text-2xl">
                The agency-grade engine for vertical video conversion. Powering the next generation of marketing funnels.
              </p>
              <div className="mt-16 pt-16 border-t border-white/5">
                <p className="text-[12px] font-black uppercase tracking-[0.4em] text-gray-600 mb-8">Architected & Managed by</p>
                <a 
                    href="https://arboradvantage.com" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="group flex items-center space-x-5 text-white hover:text-indigo-400 transition-all font-black text-4xl tracking-tighter w-fit"
                >
                    <span className="border-b-4 border-transparent group-hover:border-indigo-400 transition-all pb-2">Arbor Advantage</span>
                    <ArrowUpRight size={36} className="opacity-20 group-hover:opacity-100 group-hover:translate-x-2 group-hover:-translate-y-2 transition-all duration-500" />
                </a>
                <p className="text-gray-500 font-bold text-lg mt-6 tracking-tight">Full-Service Growth Partner for Modern Brands</p>
              </div>
            </div>
            <div>
              <h4 className="font-black uppercase tracking-[0.3em] text-[12px] text-gray-500 mb-12">Platform</h4>
              <ul className="space-y-8 text-gray-300 font-bold text-xl">
                <li><button onClick={scrollToHowItWorks} className="hover:text-indigo-400 transition-colors text-left">How it Works</button></li>
                <li><a href="#builder-demo" className="hover:text-indigo-400 transition-colors">Visual Builder</a></li>
                <li><button onClick={scrollToFeatures} className="hover:text-indigo-400 transition-colors">Feature Set</button></li>
                <li><a href="https://arboradvantage.com" className="flex items-center hover:text-indigo-400 transition-colors">Visit Our Site <ExternalLink size={20} className="ml-3 opacity-30"/></a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-black uppercase tracking-[0.3em] text-[12px] text-gray-500 mb-12">Connect</h4>
              <ul className="space-y-8 text-gray-300 font-bold text-xl">
                <li className="flex items-center group cursor-pointer hover:text-indigo-400 transition-colors">
                  <div className="w-12 h-12 rounded-[1.25rem] bg-white/5 flex items-center justify-center mr-5 group-hover:bg-indigo-600/30 transition-all"><Mail size={24} /></div>
                  jonathan@arboradvantage.com
                </li>
                <li className="flex items-center group cursor-pointer hover:text-indigo-400 transition-colors">
                   <div className="w-12 h-12 rounded-[1.25rem] bg-white/5 flex items-center justify-center mr-5 group-hover:bg-indigo-600/30 transition-all"><Globe size={24} /></div>
                   Agency Support
                </li>
              </ul>
            </div>
          </div>
          <div className="pt-20 border-t border-white/5 flex flex-col md:flex-row justify-between items-center text-gray-600 text-[12px] font-black uppercase tracking-[0.5em]">
            <p>&copy; 2025 VidFlow by Arbor Advantage. Engineering Success.</p>
            <div className="flex space-x-16 mt-12 md:mt-0">
              <a href="#" className="hover:text-white transition-colors">Privacy</a>
              <a href="#" className="hover:text-white transition-colors">Terms</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default App;
