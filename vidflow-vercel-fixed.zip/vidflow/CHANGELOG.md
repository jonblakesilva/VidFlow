# Changelog

All notable changes to VidFlow will be documented in this file.

## [1.0.0] - 2025-01-03

### Added
- ✨ Full YouTube embed support (watch, shorts, youtu.be formats)
- ✨ Direct MP4 video support
- ✨ Live floating demo widget on landing page
- ✨ Exit intent trigger functionality
- ✨ Session persistence (don't show to repeat visitors)
- ✨ Custom video thumbnails
- ✨ Autoplay with muted option
- ✨ One-click unmute CTA
- ✨ GoHighLevel form integration
- ✨ 3 GHL display modes (under-video, slide-up, replace-video)
- ✨ Custom CTA buttons (up to 3)
- ✨ 4 corner positioning options
- ✨ 3 entrance animations
- ✨ GDPR compliance text option
- ✨ White-label output (zero branding)
- ✨ Code generator for easy deployment
- ✨ Mobile responsive design

### Fixed
- 🐛 YouTube iframe autoplay now works correctly
- 🐛 YouTube controls enabled for better UX
- 🐛 Loop functionality on YouTube embeds
- 🐛 Mobile width scaling on small screens

### Technical
- Built with React 19 + TypeScript
- Vite for blazing fast dev/build
- Tailwind CSS for styling
- Lucide React icons
- Zero external dependencies for widget runtime

## [Unreleased]

### Planned
- 🔄 Vimeo embed support
- 🔄 Analytics dashboard
- 🔄 A/B testing variants
- 🔄 Scroll depth triggers
- 🔄 Advanced animation editor
- 🔄 Multi-video carousel option
