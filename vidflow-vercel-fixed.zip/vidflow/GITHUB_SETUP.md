# GitHub Repository Setup

## Initial Setup

### 1. Create GitHub Repository

```bash
# On GitHub.com:
# - Click "New Repository"
# - Name: vidflow
# - Description: Interactive video widget builder for GoHighLevel agencies
# - Public or Private (your choice)
# - DO NOT initialize with README (we have one)
# - Click "Create Repository"
```

### 2. Push Code to GitHub

```bash
# Navigate to your VidFlow directory
cd vidflow

# Initialize git (if not already done)
git init

# Add all files
git add .

# Create initial commit
git commit -m "Initial commit: VidFlow v1.0.0 - YouTube support + live demo widget"

# Add your GitHub repo as remote
git remote add origin https://github.com/YOUR_USERNAME/vidflow.git

# Push to GitHub
git branch -M main
git push -u origin main
```

### 3. Configure Repository Settings

On GitHub.com → Your Repo → Settings:

**General**
- ✅ Issues enabled
- ✅ Allow feature requests
- ✅ Projects enabled

**Pages** (Optional - for hosting docs)
- Source: Deploy from main branch
- Folder: / (root)
- Custom domain: Optional

**Secrets** (For CI/CD later)
- Add VERCEL_TOKEN if auto-deploying

---

## Repository Structure

```
vidflow/
├── .github/              # GitHub specific files
│   ├── ISSUE_TEMPLATE/   # Issue templates
│   └── workflows/        # GitHub Actions (CI/CD)
├── components/           # React components
│   ├── CodeGenerator.tsx
│   ├── ConfigPanel.tsx
│   └── PreviewPanel.tsx
├── App.tsx              # Main app
├── types.ts             # TypeScript definitions
├── index.html           # Entry point
├── index.tsx            # React entry
├── package.json         # Dependencies
├── tsconfig.json        # TypeScript config
├── vite.config.ts       # Vite build config
├── README.md            # Main documentation
├── CHANGELOG.md         # Version history
├── CONTRIBUTING.md      # Contribution guide
├── DEPLOYMENT.md        # Deployment instructions
├── LICENSE              # MIT License
└── .gitignore           # Git exclusions
```

---

## Recommended GitHub Labels

Create these labels for better issue organization:

```
bug          - #d73a4a - Something isn't working
enhancement  - #a2eeef - New feature or request
documentation- #0075ca - Improvements to docs
good first issue - #7057ff - Good for newcomers
help wanted  - #008672 - Extra attention needed
question     - #d876e3 - Further information requested
youtube      - #ffd700 - YouTube embed related
ghl          - #00ff00 - GoHighLevel integration
```

---

## Branch Strategy

```
main           - Production-ready code
develop        - Active development
feature/*      - New features
fix/*          - Bug fixes
docs/*         - Documentation updates
```

Example workflow:
```bash
# Create feature branch
git checkout -b feature/vimeo-support

# Make changes, commit
git add .
git commit -m "Add Vimeo embed support"

# Push and create PR
git push origin feature/vimeo-support
# Then create Pull Request on GitHub
```

---

## Issue Templates

Create `.github/ISSUE_TEMPLATE/bug_report.md`:

```markdown
---
name: Bug report
about: Create a report to help us improve
title: '[BUG] '
labels: bug
---

**Describe the bug**
A clear description of what the bug is.

**To Reproduce**
Steps to reproduce:
1. Go to '...'
2. Click on '....'
3. See error

**Expected behavior**
What you expected to happen.

**Screenshots**
If applicable, add screenshots.

**Environment:**
 - Browser: [e.g. Chrome, Safari]
 - OS: [e.g. Windows, Mac, iOS]
 - VidFlow Version: [e.g. 1.0.0]

**Additional context**
Any other context about the problem.
```

---

## GitHub Actions (Optional CI/CD)

Create `.github/workflows/deploy.yml`:

```yaml
name: Deploy to Vercel

on:
  push:
    branches: [ main ]

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      - uses: actions/setup-node@v2
        with:
          node-version: '18'
      - run: npm install
      - run: npm run build
      - uses: amondnet/vercel-action@v20
        with:
          vercel-token: ${{ secrets.VERCEL_TOKEN }}
          vercel-org-id: ${{ secrets.ORG_ID }}
          vercel-project-id: ${{ secrets.PROJECT_ID }}
```

---

## Release Process

### Creating a Release

1. **Update version** in package.json
2. **Update CHANGELOG.md** with changes
3. **Commit changes:**
```bash
git add .
git commit -m "chore: bump version to 1.1.0"
git push
```

4. **Create tag:**
```bash
git tag -a v1.1.0 -m "Release version 1.1.0"
git push origin v1.1.0
```

5. **Create GitHub Release:**
   - Go to Releases → New Release
   - Choose your tag (v1.1.0)
   - Title: "VidFlow v1.1.0 - [Feature Name]"
   - Description: Copy from CHANGELOG
   - Attach built files if needed
   - Publish

---

## Community Management

### Responding to Issues

- ✅ Respond within 24-48 hours
- ✅ Ask for reproduction steps if unclear
- ✅ Label appropriately
- ✅ Link to relevant docs
- ✅ Close when resolved

### Pull Request Reviews

Check for:
- [ ] Code follows existing style
- [ ] No breaking changes (or documented)
- [ ] Tests pass (when we add them)
- [ ] Documentation updated
- [ ] CHANGELOG.md updated

---

## Promotion

### Share Your Repo

**GHL Community:**
- Facebook Groups
- GHL Marketplace
- Reddit r/gohighlevel

**Developer Communities:**
- Product Hunt
- Indie Hackers
- Dev.to article

**SEO:**
- Add topics: `gohighlevel`, `video-widget`, `conversion`, `react`
- Star your own repo
- Add to your GitHub profile README

---

## Maintenance

### Regular Tasks

**Weekly:**
- Check for new issues
- Review open PRs
- Update dependencies: `npm audit fix`

**Monthly:**
- Review analytics (GitHub Insights)
- Update documentation
- Plan new features

**Quarterly:**
- Major version updates
- Security audit
- Performance review

---

## Support Channels

- **GitHub Issues** - Bug reports, features
- **GitHub Discussions** - Q&A, ideas
- **Email** - jonathan@arboradvantage.com
- **Website** - https://arboradvantage.com

---

**Ready to go viral in the GHL community? Push to GitHub and share! 🚀**
