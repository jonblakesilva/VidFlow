# Contributing to VidFlow

First off, thanks for taking the time to contribute! 🎉

## How Can I Contribute?

### Reporting Bugs

**Before submitting a bug report:**
- Check the existing issues to avoid duplicates
- Test with the latest version
- Collect reproduction steps

**When submitting:**
- Use a clear, descriptive title
- Provide exact steps to reproduce
- Include browser/OS info
- Add screenshots if relevant

### Suggesting Features

We love feature ideas! When suggesting:
- Explain the use case clearly
- Describe the expected behavior
- Consider how it fits with existing features
- Check if it aligns with GHL agency workflows

### Pull Requests

1. **Fork the repo** and create your branch from `main`
2. **Make your changes** with clear, focused commits
3. **Test thoroughly** - does it work in all browsers?
4. **Update documentation** if you changed APIs
5. **Follow the existing code style**
6. **Submit the PR** with a clear description

## Development Setup

```bash
# Clone your fork
git clone https://github.com/your-username/vidflow.git
cd vidflow

# Install dependencies
npm install

# Start dev server
npm run dev

# Build for production
npm run build
```

## Code Style

- TypeScript for type safety
- Functional components with hooks
- Descriptive variable names
- Comments for complex logic
- Keep components focused and small

## Commit Messages

Use clear, imperative messages:

```
✅ Add YouTube shorts support
✅ Fix autoplay on Safari
✅ Update README with deployment guide

❌ fixed stuff
❌ changes
❌ asdf
```

## Testing

Before submitting:
- [ ] Test in Chrome, Firefox, Safari
- [ ] Test on mobile (iOS & Android)
- [ ] Test YouTube AND direct MP4 videos
- [ ] Test GHL form integration
- [ ] Check console for errors

## Questions?

Open an issue with the `question` label or reach out to [Arbor Advantage](https://arboradvantage.com).

---

**Remember:** This tool is built for GHL agencies by operators. Keep the end user (agency owners) in mind!
